module.exports = {
  TOKEN: process.env.DISCORD_BOT_TOKEN,
  INITIAL_BUDGET: 300000,
  MIN_BET: 100,
  MAX_BET: 50000,
  GAMES: {
    PENGUIN: {
      GRID_SIZE: 9,
      WIN_MULTIPLIER: 2,
      POLAR_BEAR_PENALTY: 0.5
    },
    GIFT: {
      MAX_ATTEMPTS: 3,
      WIN_MULTIPLIER: 3
    }
  }
};