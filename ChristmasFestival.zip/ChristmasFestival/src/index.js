const { Client, GatewayIntentBits, Permissions } = require('discord.js');
const { commands } = require('./commands');
const { TOKEN } = require('./config');
const { createLogger, format, transports } = require('winston');

// Configure Winston logger
const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.printf(info => `${info.timestamp} ${info.level}: ${info.message}`)
  ),
  transports: [
    new transports.Console(),
    new transports.File({ filename: 'error.log', level: 'error' }),
    new transports.File({ filename: 'combined.log' })
  ]
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildEmojisAndStickers
  ]
});

client.once('ready', () => {
  logger.info(`Bot avviato con successo come ${client.user.tag}`);
  const inviteLink = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=277025392704&scope=bot`;
  logger.info(`Link di invito: ${inviteLink}`);
  logger.info('Intents configurati correttamente');
  logger.info('Server connessi:');
  client.guilds.cache.forEach(guild => {
    logger.info(`- ${guild.name} (ID: ${guild.id})`);
    guild.channels.cache
      .filter(channel => channel.type === 0 && channel.permissionsFor(guild.members.me).has('SendMessages'))
      .first()?.send('Bot riavviato con successo! Usa !help per vedere i comandi disponibili.')
      .catch(error => logger.error(`Errore nell'invio del messaggio in ${guild.name}:`, error));
  });
  logger.info(`Numero totale di server: ${client.guilds.cache.size}`);
  logger.info('In attesa di comandi...');

  // Imposta lo stato del bot
  client.user.setPresence({
    activities: [{ name: '!help per i comandi' }],
    status: 'online'
  });
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  const prefix = '!';
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (commands[command]) {
    try {
      logger.info(`Esecuzione comando: ${command} da ${message.author.tag} in ${message.guild?.name || 'DM'}`);
      await commands[command](message, args);
    } catch (error) {
      logger.error('Errore durante l\'esecuzione del comando:', error);
      logger.error('Dettagli comando:', { command, args, user: message.author.tag });
      message.reply('Mi dispiace, si è verificato un errore durante l\'esecuzione del comando. Riprova più tardi.');
    }
  }
});

client.on('guildCreate', async guild => {
  logger.info(`Bot aggiunto al server: ${guild.name} (ID: ${guild.id})`);

  const channel = guild.channels.cache
    .filter(channel => channel.type === 0 && channel.permissionsFor(guild.members.me).has('SendMessages'))
    .first();

  if (channel) {
    try {
      await channel.send('Ciao! Sono il bot dei giochi natalizi! Usa !help per vedere i comandi disponibili.');
    } catch (error) {
      logger.error(`Errore nell'invio del messaggio di benvenuto in ${guild.name}:`, error);
    }
  } else {
    logger.error(`Non ho trovato un canale dove posso scrivere in ${guild.name}`);
  }
});

client.on('error', error => {
  logger.error('Errore globale del client Discord:', error);
});

process.on('unhandledRejection', error => {
  logger.error('Errore non gestito:', error);
});

client.login(TOKEN).catch(error => {
  logger.error('Errore durante il login del bot:', error);
  process.exit(1);
});