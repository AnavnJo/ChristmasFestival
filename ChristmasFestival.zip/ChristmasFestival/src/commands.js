const { coinflip } = require('./games/coinflip');
const { giftGame } = require('./games/gift');
const { penguinGame } = require('./games/penguin');
const { christmasCoinflip } = require('./games/christmas_coinflip');
const { reindeerGame } = require('./games/reindeer');
const { elfHighLow } = require('./games/elf_highlow');
const { santaFinderGame } = require('./games/santa_finder');
const { polarBoxGame } = require('./games/polar_boxes');
const { sleighDashGame } = require('./games/sleigh_dash');
const { memoryGame } = require('./games/christmas_memory');
const { luckyTreeGame } = require('./games/lucky_tree');
const { getBudget, addBudget, donate } = require('./utils/budget');
const { helpMessage } = require('./utils/messages');
const { quizGame } = require('./games/quiz_game');
const { 
  startTombola,
  joinTombola,
  startExtraction,
  extractNumber,
  claimWin,
  showCard
} = require('./games/tombola');
const { briscolaGame } = require('./games/briscola');
const { trisGame } = require('./games/tris');
const { dadiGame } = require('./games/dadi');
const { setteEMezzoGame } = require('./games/sette_mezzo');
const { detectiveReindeerGame } = require('./games/detective_reindeer');

const commands = {
  help: async (message) => {
    message.channel.send(helpMessage);
  },

  budget: async (message) => {
    const budget = getBudget(message.author.id);
    message.reply(`Il tuo budget attuale è: €${budget.toLocaleString()}`);
  },

  dona: async (message, args) => {
    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount <= 0) {
      return message.reply('Specifica un importo valido da donare.');
    }

    const success = donate(message.author.id, amount);
    if (success) {
      message.reply(`Hai donato €${amount.toLocaleString()} alla chiesa. Che Dio ti benedica! 🙏`);
    } else {
      message.reply('Non hai abbastanza fondi per questa donazione.');
    }
  },

  coinflip: async (message, args) => {
    await coinflip(message, args);
  },

  nataleflip: async (message, args) => {
    await christmasCoinflip(message, args);
  },

  regalo: async (message, args) => {
    await giftGame(message, args);
  },

  pinguino: async (message, args) => {
    await penguinGame(message, args);
  },

  renna: async (message, args) => {
    await reindeerGame(message, args);
  },

  elfi: async (message, args) => {
    await elfHighLow(message, args);
  },

  trovasanta: async (message, args) => {
    await santaFinderGame(message, args);
  },

  pacchi: async (message, args) => {
    await polarBoxGame(message, args);
  },

  slittadash: async (message, args) => {
    await sleighDashGame(message, args);
  },

  memory: async (message, args) => {
    await memoryGame(message, args);
  },

  albero: async (message, args) => {
    await luckyTreeGame(message, args);
  },

  quiz: async (message, args) => {
    await quizGame(message, args);
  },

  tombola: async (message, args) => {
    await startTombola(message, args);
  },

  partecipa: async (message) => {
    await joinTombola(message);
  },

  via: async (message) => {
    await startExtraction(message);
  },

  numero: async (message) => {
    await extractNumber(message);
  },

  ambo: async (message) => {
    await claimWin(message, 'ambo');
  },

  terna: async (message) => {
    await claimWin(message, 'terna');
  },

  cinquina: async (message) => {
    await claimWin(message, 'cinquina');
  },

  cartella: async (message) => {
    await showCard(message);
  },
  briscola: async (message, args) => {
    await briscolaGame(message, args);
  },
  tris: async (message, args) => {
    await trisGame(message, args);
  },

  dadi: async (message, args) => {
    await dadiGame(message, args);
  },

  setteemezzo: async (message, args) => {
    await setteEMezzoGame(message, args);
  },
  detective: async (message, args) => {
    await detectiveReindeerGame(message, args);
  }
};

module.exports = { commands };