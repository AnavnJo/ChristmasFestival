const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const WORLD_SIZE = 16;
const WORLD_EMOJIS = ['🌲', '🎄', '⛄', '🎁'];

const reindeerGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !renna <puntata>\nEsempio: !renna 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  // Create world grid
  const world = Array(WORLD_SIZE).fill().map(() => 
    WORLD_EMOJIS[Math.floor(Math.random() * WORLD_EMOJIS.length)]
  );
  
  const reindeerPosition = Math.floor(Math.random() * WORLD_SIZE);
  const displayWorld = () => {
    let display = '';
    for (let i = 0; i < world.length; i++) {
      display += `${world[i]} `;
      if ((i + 1) % 4 === 0) display += '\n';
    }
    return display;
  };

  message.reply(`Trova la Renna Cometa nel mondo natalizio! Scegli una posizione da 1 a ${WORLD_SIZE}\n${displayWorld()}`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= WORLD_SIZE;

  try {
    const collected = await message.channel.awaitMessages({ 
      filter, 
      max: 1, 
      time: 30000 
    });

    const choice = parseInt(collected.first().content) - 1;
    world[reindeerPosition] = '🦌';

    if (choice === reindeerPosition) {
      const win = bet * 4;
      addBudget(message.author.id, win);
      message.reply(`Congratulazioni! Hai trovato la Renna Cometa! 🎉\nHai vinto €${win.toLocaleString()}!\n${displayWorld()}`);
    } else {
      world[choice] = '❌';
      addBudget(message.author.id, -bet);
      message.reply(`Oh no! La Renna Cometa era in un'altra posizione! Hai perso €${bet.toLocaleString()}\n${displayWorld()}`);
    }
  } catch (error) {
    message.reply('Tempo scaduto! La Renna Cometa è scappata!');
  }
};

module.exports = { reindeerGame };
