const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

// Mappa per tenere traccia delle partite in corso
const activeGames = new Map();

class TombolaGame {
  constructor(bet) {
    this.numbers = Array.from({length: 65}, (_, i) => i + 1);
    this.extractedNumbers = [];
    this.players = new Map();
    this.bet = bet;
    this.prizes = {
      ambo: bet * 2,
      terna: bet * 3,
      cinquina: bet * 5,
      tombola: bet * 10
    };
    this.winners = {
      ambo: null,
      terna: null,
      cinquina: null,
      tombola: null
    };
    this.status = 'waiting'; // waiting, running, finished
  }

  generateCard() {
    const card = Array(3).fill().map(() => Array(9).fill(null));
    let remainingNumbers = 15;

    // Distribuzione dei numeri nelle colonne
    const numberRanges = [
      [1, 9], [10, 19], [20, 29], [30, 39], 
      [40, 49], [50, 55], [56, 60], [61, 65]
    ];

    // Assegna numeri casuali per ogni colonna
    numberRanges.forEach((range, colIndex) => {
      const numbersInRange = Array.from(
        {length: range[1] - range[0] + 1}, 
        (_, i) => range[0] + i
      );

      // Numero di numeri da inserire in questa colonna
      const numbersToInsert = Math.min(
        Math.floor(remainingNumbers / (8 - colIndex)),
        3
      );

      if (numbersToInsert > 0) {
        // Seleziona posizioni casuali nella colonna
        const rowPositions = Array.from({length: 3}, (_, i) => i)
          .sort(() => Math.random() - 0.5)
          .slice(0, numbersToInsert);

        rowPositions.forEach(rowIndex => {
          const randomIndex = Math.floor(Math.random() * numbersInRange.length);
          card[rowIndex][colIndex] = numbersInRange[randomIndex];
          numbersInRange.splice(randomIndex, 1);
          remainingNumbers--;
        });
      }
    });

    return card;
  }

  addPlayer(playerId) {
    if (this.status !== 'waiting') {
      return false;
    }
    this.players.set(playerId, {
      card: this.generateCard(),
      matches: new Set(),
      claimed: new Set()
    });
    return true;
  }

  extractNumber() {
    if (this.numbers.length === 0 || this.status !== 'running') {
      return null;
    }
    const index = Math.floor(Math.random() * this.numbers.length);
    const number = this.numbers[index];
    this.numbers.splice(index, 1);
    this.extractedNumbers.push(number);

    // Aggiorna automaticamente i numeri segnati per ogni giocatore
    for (const [playerId, player] of this.players) {
      player.card.forEach((row, rowIndex) => {
        row.forEach((num, colIndex) => {
          if (num === number) {
            player.matches.add(`${rowIndex}-${colIndex}`);
          }
        });
      });
    }

    return number;
  }

  checkWin(playerId, type) {
    if (!this.players.has(playerId) || this.winners[type]) {
      return false;
    }

    const player = this.players.get(playerId);
    if (player.claimed.has(type)) {
      return false;
    }

    const rows = [0, 0, 0];
    player.card.forEach((row, rowIndex) => {
      row.forEach((num, colIndex) => {
        if (num && this.extractedNumbers.includes(num)) {
          rows[rowIndex]++;
        }
      });
    });

    let isWin = false;
    switch (type) {
      case 'ambo':
        isWin = rows.some(count => count >= 2);
        break;
      case 'terna':
        isWin = rows.some(count => count >= 3);
        break;
      case 'cinquina':
        isWin = rows.some(count => count >= 5);
        break;
      case 'tombola':
        isWin = player.card.flat().filter(num => num && this.extractedNumbers.includes(num)).length === 15;
        break;
    }

    if (isWin) {
      this.winners[type] = playerId;
      player.claimed.add(type);
      if (type === 'tombola') {
        this.status = 'finished';
      }
    }

    return isWin;
  }

  formatCard(card, matches) {
    return card.map((row, rowIndex) => 
      row.map((num, colIndex) => {
        if (!num) return '··';
        const numStr = num.toString().padStart(2, '0');
        // Aggiungi un indicatore per i numeri segnati (✓)
        return matches.has(`${rowIndex}-${colIndex}`) ? `${numStr}✓` : numStr;
      }).join(' ')
    ).join('\n');
  }

  getGameStatus() {
    const extractedStr = this.extractedNumbers
      .slice(-5)
      .map(n => n.toString().padStart(2, '0'))
      .join(' ');
    
    let status = `🎲 Ultimi numeri estratti: ${extractedStr}\n`;
    status += `📊 Numeri estratti: ${this.extractedNumbers.length}/65\n\n`;
    
    Object.entries(this.winners).forEach(([type, winnerId]) => {
      if (winnerId) {
        status += `🏆 ${type.toUpperCase()}: Vinto! (€${this.prizes[type].toLocaleString()})\n`;
      } else {
        status += `⌛ ${type.toUpperCase()}: Disponibile (€${this.prizes[type].toLocaleString()})\n`;
      }
    });
    
    return status;
  }
  showCard(playerId) {
    const player = this.players.get(playerId);
    if (!player) return null;

    return this.formatCard(player.card, player.matches);
  }
}

const startTombola = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !tombola <puntata>\nEsempio: !tombola 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const channelId = message.channel.id;
  if (activeGames.has(channelId)) {
    return message.reply('C\'è già una partita in corso in questo canale!');
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  addBudget(message.author.id, -bet);
  const game = new TombolaGame(bet);
  activeGames.set(channelId, game);
  game.addPlayer(message.author.id);

  message.reply(`
🎰 Nuova partita di Tombola Natalizia! 🎄

Premi:
• Ambo: €${game.prizes.ambo.toLocaleString()}
• Terna: €${game.prizes.terna.toLocaleString()}
• Cinquina: €${game.prizes.cinquina.toLocaleString()}
• Tombola: €${game.prizes.tombola.toLocaleString()}

La tua cartella:
\`\`\`
${game.showCard(message.author.id)}
\`\`\`

Altri giocatori possono unirsi con !partecipa
Usa !via per iniziare l'estrazione!
`);
};

const joinTombola = async (message) => {
  const channelId = message.channel.id;
  const game = activeGames.get(channelId);
  
  if (!game) {
    return message.reply('Non c\'è nessuna partita in corso in questo canale!');
  }

  if (game.status !== 'waiting') {
    return message.reply('La partita è già iniziata!');
  }

  const userBudget = getBudget(message.author.id);
  if (game.bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per partecipare! (€${game.bet.toLocaleString()})`);
  }

  if (game.players.has(message.author.id)) {
    return message.reply('Sei già nella partita!');
  }

  addBudget(message.author.id, -game.bet);
  game.addPlayer(message.author.id);

  message.reply(`
Ti sei unito alla Tombola! 🎉

La tua cartella:
\`\`\`
${game.showCard(message.author.id)}
\`\`\`
`);
};

const startExtraction = async (message) => {
  const channelId = message.channel.id;
  const game = activeGames.get(channelId);
  
  if (!game) {
    return message.reply('Non c\'è nessuna partita in corso in questo canale!');
  }

  if (game.status !== 'waiting') {
    return message.reply('La partita è già iniziata!');
  }

  game.status = 'running';
  message.reply('🎲 Inizia l\'estrazione! Usa !numero per estrarre il prossimo numero.');
};

const extractNumber = async (message) => {
  const channelId = message.channel.id;
  const game = activeGames.get(channelId);
  
  if (!game) {
    return message.reply('Non c\'è nessuna partita in corso in questo canale!');
  }

  if (game.status !== 'running') {
    return message.reply('La partita non è ancora iniziata o è già finita!');
  }

  const number = game.extractNumber();
  if (!number) {
    game.status = 'finished';
    return message.reply('🎮 Game Over! Tutti i numeri sono stati estratti!');
  }

  message.reply(`
🎲 Numero estratto: ${number}

${game.getGameStatus()}

Usa !ambo, !terna, !cinquina o !tombola per dichiarare la vittoria!
Usa !numero per la prossima estrazione.
`);
};

const claimWin = async (message, type) => {
  const channelId = message.channel.id;
  const game = activeGames.get(channelId);
  
  if (!game) {
    return message.reply('Non c\'è nessuna partita in corso in questo canale!');
  }

  if (game.status !== 'running') {
    return message.reply('La partita non è ancora iniziata o è già finita!');
  }

  if (!game.players.has(message.author.id)) {
    return message.reply('Non sei nella partita!');
  }

  const isWin = game.checkWin(message.author.id, type);
  if (isWin) {
    const prize = game.prizes[type];
    addBudget(message.author.id, prize);
    message.reply(`
🎉 Congratulazioni! Hai fatto ${type.toUpperCase()}!
Hai vinto €${prize.toLocaleString()}!

${game.getGameStatus()}
`);

    if (type === 'tombola') {
      activeGames.delete(channelId);
      return message.reply('🎮 Partita terminata!');
    }
  } else {
    message.reply('❌ Verifica fallita! Non hai ancora fatto ' + type);
  }
};

const showCard = async (message) => {
  const channelId = message.channel.id;
  const game = activeGames.get(channelId);
  
  if (!game) {
    return message.reply('Non c\'è nessuna partita in corso in questo canale!');
  }

  if (!game.players.has(message.author.id)) {
    return message.reply('Non sei nella partita!');
  }

  message.reply(`
La tua cartella:
\`\`\`
${game.showCard(message.author.id)}
\`\`\`

${game.getGameStatus()}
`);
};

module.exports = { 
  startTombola,
  joinTombola,
  startExtraction,
  extractNumber,
  claimWin,
  showCard
};