const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const LOCATIONS = [
  { name: 'Polo Nord', emoji: '🌨️' },
  { name: 'New York', emoji: '🗽' },
  { name: 'Parigi', emoji: '🗼' },
  { name: 'Tokyo', emoji: '🗾' },
  { name: 'Sydney', emoji: '🦘' },
  { name: 'Rio de Janeiro', emoji: '🏖️' },
  { name: 'Londra', emoji: '🎡' },
  { name: 'Mosca', emoji: '⛪' },
  { name: 'Dubai', emoji: '🌇' },
  { name: 'Roma', emoji: '🏛️' }
];

const santaFinderGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !trovasanta <puntata>\nEsempio: !trovasanta 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const santaLocation = Math.floor(Math.random() * LOCATIONS.length);
  
  let locationsList = '';
  LOCATIONS.forEach((loc, index) => {
    locationsList += `${index + 1}. ${loc.name} ${loc.emoji}\n`;
  });

  message.reply(`🎅 Santa Claus si è nascosto in una di queste città! Indovina dove!\n\n${locationsList}\nScegli un numero da 1 a ${LOCATIONS.length}`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= LOCATIONS.length;

  try {
    const collected = await message.channel.awaitMessages({ 
      filter, 
      max: 1, 
      time: 30000 
    });

    const choice = parseInt(collected.first().content) - 1;

    if (choice === santaLocation) {
      const win = bet * 5;  // 5x multiplier for finding Santa
      addBudget(message.author.id, win);
      message.reply(`🎉 Incredibile! Hai trovato Santa Claus a ${LOCATIONS[santaLocation].name} ${LOCATIONS[santaLocation].emoji}!\nHai vinto €${win.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
    } else {
      addBudget(message.author.id, -bet);
      message.reply(`❌ Oh no! Santa non era a ${LOCATIONS[choice].name} ${LOCATIONS[choice].emoji}! Era a ${LOCATIONS[santaLocation].name} ${LOCATIONS[santaLocation].emoji}!\nHai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
    }
  } catch (error) {
    message.reply('⏰ Tempo scaduto! Santa è già partito per un\'altra città!');
  }
};

module.exports = { santaFinderGame };
