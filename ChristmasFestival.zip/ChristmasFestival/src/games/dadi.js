const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const DADI_FACCE = {
  1: `
┌─────────┐
│         │
│    •    │
│         │
└─────────┘`,
  2: `
┌─────────┐
│  •      │
│         │
│      •  │
└─────────┘`,
  3: `
┌─────────┐
│  •      │
│    •    │
│      •  │
└─────────┘`,
  4: `
┌─────────┐
│  •   •  │
│         │
│  •   •  │
└─────────┘`,
  5: `
┌─────────┐
│  •   •  │
│    •    │
│  •   •  │
└─────────┘`,
  6: `
┌─────────┐
│  •   •  │
│  •   •  │
│  •   •  │
└─────────┘`
};

const displayDice = (numeri) => {
  // Dividi ogni dado in righe
  const righe = numeri.map(n => DADI_FACCE[n].split('\n'));
  // Combina le righe corrispondenti di ogni dado
  let display = '';
  for (let i = 0; i < righe[0].length; i++) {
    display += righe.map(r => r[i]).join('  ') + '\n';
  }
  return display;
};

const dadiGame = async (message, args) => {
  if (args.length !== 2) {
    return message.reply(`
🎲 Dadi - Modalità di gioco:
!dadi <scelta> <puntata>

Scelte disponibili:
1. somma - Indovina se la somma sarà sopra/sotto 7
2. doppio - Punta sul doppio numero
3. poker - Punta su quattro dadi uguali (x50)
4. scala - Punta su una scala di quattro dadi (x30)
5. tris - Punta su tre dadi uguali (x15)

Esempio: !dadi somma 1000
`);
  }

  const [tipo, puntataStr] = args;
  const puntata = parseInt(puntataStr);

  if (isNaN(puntata) || puntata < MIN_BET || puntata > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (puntata > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  // Tira 4 dadi
  const dadi = Array.from({length: 4}, () => Math.floor(Math.random() * 6) + 1);
  const somma = dadi.reduce((a, b) => a + b, 0);

  // Funzioni di verifica
  const hasDoppio = () => new Set(dadi).size < 4;
  const hasPoker = () => new Set(dadi).size === 1;
  const hasTris = () => {
    const conteggio = {};
    dadi.forEach(d => conteggio[d] = (conteggio[d] || 0) + 1);
    return Object.values(conteggio).some(count => count >= 3);
  };
  const hasScala = () => {
    const sorted = [...dadi].sort((a, b) => a - b);
    for (let i = 1; i < sorted.length; i++) {
      if (sorted[i] !== sorted[i-1] + 1) return false;
    }
    return true;
  };

  // Mostra i dadi
  message.reply(`
🎲 I dadi mostrano:
${displayDice(dadi)}
Somma: ${somma}
`);

  switch (tipo.toLowerCase()) {
    case 'somma':
      message.reply('Scegli: sopra o sotto 7?');
      try {
        const filter = m => m.author.id === message.author.id && 
                          ['sopra', 'sotto'].includes(m.content.toLowerCase());
        const collected = await message.channel.awaitMessages({ 
          filter, max: 1, time: 30000 
        });

        const scelta = collected.first().content.toLowerCase();
        const vincita = (scelta === 'sopra' && somma > 7) || (scelta === 'sotto' && somma < 7);
        
        if (vincita) {
          const win = puntata * 2;
          addBudget(message.author.id, win);
          message.reply(`
🎉 Hai vinto! La somma è ${scelta} il 7!
Hai vinto €${win.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
        } else {
          addBudget(message.author.id, -puntata);
          message.reply(`
😢 Hai perso! La somma non è ${scelta} il 7.
Hai perso €${puntata.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
        }
      } catch (error) {
        return message.reply('⏰ Tempo scaduto!');
      }
      break;

    case 'doppio':
      if (hasDoppio()) {
        const win = puntata * 3;
        addBudget(message.author.id, win);
        message.reply(`
🎉 Hai fatto doppio!
Hai vinto €${win.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      } else {
        addBudget(message.author.id, -puntata);
        message.reply(`
😢 Nessun doppio.
Hai perso €${puntata.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      }
      break;

    case 'poker':
      if (hasPoker()) {
        const win = puntata * 50;
        addBudget(message.author.id, win);
        message.reply(`
🎉 POKER! Quattro dadi uguali!
Hai vinto €${win.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      } else {
        addBudget(message.author.id, -puntata);
        message.reply(`
😢 Nessun poker.
Hai perso €${puntata.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      }
      break;

    case 'scala':
      if (hasScala()) {
        const win = puntata * 30;
        addBudget(message.author.id, win);
        message.reply(`
🎉 SCALA! Quattro numeri consecutivi!
Hai vinto €${win.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      } else {
        addBudget(message.author.id, -puntata);
        message.reply(`
😢 Nessuna scala.
Hai perso €${puntata.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      }
      break;

    case 'tris':
      if (hasTris()) {
        const win = puntata * 15;
        addBudget(message.author.id, win);
        message.reply(`
🎉 TRIS! Tre dadi uguali!
Hai vinto €${win.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      } else {
        addBudget(message.author.id, -puntata);
        message.reply(`
😢 Nessun tris.
Hai perso €${puntata.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      }
      break;

    default:
      message.reply('Tipo di gioco non valido! Usa: somma, doppio, poker, scala, o tris');
  }
};

module.exports = { dadiGame };
