const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const CATEGORIES = {
  CHRISTMAS: 'Natale 🎄',
  ASTROPHYSICS: 'Astrofisica 🌌',
  ASTRONOMY: 'Astronomia 🔭',
  PHYSICS: 'Fisica ⚛️',
  MATH: 'Matematica 📐',
  MARINE_BIOLOGY: 'Biologia Marina 🌊',
  BIOLOGY: 'Biologia 🧬',
  HISTORY: 'Storia 📚',
  ART_HISTORY: 'Storia dell\'Arte 🎨'
};

const QUIZ_QUESTIONS = {
  [CATEGORIES.CHRISTMAS]: [
    {
      question: 'Quale renna di Babbo Natale ha il naso rosso?',
      options: ['Rudolph', 'Dasher', 'Dancer', 'Prancer'],
      correct: 0,
      explanation: 'Rudolph è la famosa renna dal naso rosso che guida la slitta di Babbo Natale nelle notti nebbiose.'
    },
    {
      question: 'In quale paese è nata la tradizione dell\'albero di Natale?',
      options: ['Germania', 'Stati Uniti', 'Italia', 'Francia'],
      correct: 0,
      explanation: 'La tradizione dell\'albero di Natale ha origine in Germania nel XVI secolo.'
    },
    {
      question: 'Quale pianta è tradizionalmente associata al Natale?',
      options: ['Vischio', 'Rosa', 'Girasole', 'Tulipano'],
      correct: 0,
      explanation: 'Il vischio è tradizionalmente appeso nelle case durante il Natale ed è simbolo di pace e amore.'
    },
    {
      question: 'Qual è il dolce natalizio italiano per eccellenza?',
      options: ['Panettone', 'Tiramisù', 'Cannoli', 'Sfogliatella'],
      correct: 0,
      explanation: 'Il panettone è il dolce natalizio italiano più famoso, originario di Milano.'
    },
    {
      question: 'In quale giorno si celebra la festa dell\'Epifania?',
      options: ['6 gennaio', '25 dicembre', '1 gennaio', '8 dicembre'],
      correct: 0,
      explanation: 'L\'Epifania si celebra il 6 gennaio e in Italia è tradizionalmente associata alla Befana.'
    },
    {
      question: 'Quale paese ha iniziato la tradizione della corona dell\'Avvento?',
      options: ['Germania', 'Svezia', 'Italia', 'Inghilterra'],
      correct: 0,
      explanation: 'La corona dell\'Avvento è una tradizione natalizia originaria della Germania nel XVI secolo.'
    },
    {
      question: 'Quale oggetto secondo la tradizione i Re Magi seguirono per trovare Gesù?',
      options: ['La stella cometa', 'Un angelo', 'Una colomba', 'Un arcobaleno'],
      correct: 0,
      explanation: 'Secondo la tradizione, i Re Magi seguirono la stella cometa che li guidò fino a Betlemme.'
    },
    {
      question: 'In quale città italiana è nata la tradizione del presepe?',
      options: ['Napoli', 'Roma', 'Firenze', 'Milano'],
      correct: 0,
      explanation: 'Napoli è famosa per la sua tradizione presepiale, con la storica via San Gregorio Armeno.'
    },
    {
      question: 'Quale bevanda è tradizionalmente associata al Natale nei paesi anglosassoni?',
      options: ['Eggnog', 'Vino caldo', 'Cioccolata calda', 'Tè'],
      correct: 0,
      explanation: 'L\'eggnog è una bevanda natalizia a base di latte, uova e spezie, tipica dei paesi anglosassoni.'
    },
    {
      question: 'Chi ha scritto "Canto di Natale"?',
      options: ['Charles Dickens', 'William Shakespeare', 'Oscar Wilde', 'Jane Austen'],
      correct: 0,
      explanation: 'Charles Dickens scrisse "Canto di Natale" nel 1843, una delle storie natalizie più famose al mondo.'
    }
  ],
  [CATEGORIES.ASTROPHYSICS]: [
    {
      question: 'Quale è il processo principale che genera energia nelle stelle?',
      options: ['Fusione nucleare', 'Fissione nucleare', 'Combustione chimica', 'Radioattività'],
      correct: 0,
      explanation: 'La fusione nucleare dell\'idrogeno in elio è il principale processo che genera energia nelle stelle.'
    },
    {
      question: 'Cosa succede quando una stella massiccia termina il suo combustibile nucleare?',
      options: ['Diventa una supernova', 'Si trasforma in un pianeta', 'Scompare', 'Si raffredda lentamente'],
      correct: 0,
      explanation: 'Le stelle massicce esplodono come supernove quando esauriscono il loro combustibile nucleare.'
    },
    {
      question: 'Quale oggetto celeste ha una gravità così forte che nemmeno la luce può sfuggire?',
      options: ['Buco nero', 'Stella di neutroni', 'Nana bianca', 'Gigante rossa'],
      correct: 0,
      explanation: 'Un buco nero ha un campo gravitazionale così intenso che supera la velocità di fuga della luce.'
    },
    {
      question: 'Quale particella è responsabile dell\'interazione gravitazionale?',
      options: ['Gravitone', 'Fotone', 'Elettrone', 'Quark'],
      correct: 0,
      explanation: 'Il gravitone è la particella teorica che si ritiene sia responsabile della forza gravitazionale.'
    },
    {
      question: 'Quale è la temperatura approssimativa del nucleo del Sole?',
      options: ['15 milioni °C', '5 milioni °C', '1 milione °C', '10 milioni °C'],
      correct: 0,
      explanation: 'Il nucleo del Sole raggiunge temperature di circa 15 milioni di gradi Celsius, necessarie per la fusione nucleare.'
    },
    {
      question: 'Cosa succede alla materia quando cade in un buco nero?',
      options: ['Viene spaghetticata', 'Scompare istantaneamente', 'Rimbalza indietro', 'Si congela'],
      correct: 0,
      explanation: 'La spaghetticazione è l\'effetto delle forze mareali di un buco nero che stirano la materia verticalmente e la comprimono orizzontalmente.'
    },
    {
      question: 'Quale è il processo principale che alimenta le stelle nella sequenza principale?',
      options: ['Catena protone-protone', 'Fissione dell\'uranio', 'Ciclo del carbonio', 'Decadimento radioattivo'],
      correct: 0,
      explanation: 'La catena protone-protone è il principale processo di fusione nucleare nelle stelle di massa simile al Sole.'
    },
    {
      question: 'Cosa è l\'effetto Doppler in astrofisica?',
      options: ['Spostamento della luce verso il rosso/blu', 'Rifrazione della luce', 'Assorbimento della luce', 'Polarizzazione della luce'],
      correct: 0,
      explanation: 'L\'effetto Doppler causa uno spostamento verso il rosso o il blu della luce a seconda se la fonte si allontana o si avvicina.'
    },
    {
      question: 'Quale è la teoria più accettata sull\'origine dell\'universo?',
      options: ['Big Bang', 'Stato stazionario', 'Universo ciclico', 'Multiverso'],
      correct: 0,
      explanation: 'La teoria del Big Bang è supportata da evidenze come la radiazione cosmica di fondo e l\'espansione dell\'universo.'
    },
    {
      question: 'Cosa è una stella di neutroni?',
      options: ['Il nucleo collassato di una stella massiccia', 'Una stella giovane', 'Una stella binaria', 'Un ammasso stellare'],
      correct: 0,
      explanation: 'Una stella di neutroni si forma quando il nucleo di una stella massiccia collassa dopo una supernova.'
    },
    {
      question: 'Quale particella è associata alla forza elettromagnetica?',
      options: ['Fotone', 'Gravitone', 'Gluone', 'Bosone W'],
      correct: 0,
      explanation: 'Il fotone è il bosone mediatore della forza elettromagnetica.'
    },
    {
      question: 'Cosa è l\'energia oscura?',
      options: ['La forza che accelera l\'espansione dell\'universo', 'Materia oscura', 'Radiazione cosmica', 'Antimateria'],
      correct: 0,
      explanation: 'L\'energia oscura è una forma di energia che causa l\'accelerazione dell\'espansione dell\'universo.'
    }
  ],
  [CATEGORIES.ASTRONOMY]: [
    {
      question: 'Qual è il pianeta più grande del sistema solare?',
      options: ['Giove', 'Saturno', 'Urano', 'Nettuno'],
      correct: 0,
      explanation: 'Giove è il pianeta più grande del sistema solare, con una massa 318 volte quella della Terra.'
    },
    {
      question: 'Quale galassia è la più vicina alla Via Lattea?',
      options: ['Andromeda', 'Triangolo', 'Grande Nube di Magellano', 'Piccola Nube di Magellano'],
      correct: 0,
      explanation: 'La galassia di Andromeda (M31) è la galassia spirale più vicina alla nostra Via Lattea.'
    },
    {
      question: 'Quanto tempo impiega la luce del Sole per raggiungere la Terra?',
      options: ['8 minuti', '1 ora', '24 ore', '1 secondo'],
      correct: 0,
      explanation: 'La luce del Sole impiega circa 8 minuti per percorrere la distanza di 150 milioni di km che lo separa dalla Terra.'
    },
    {
      question: 'Qual è il pianeta più caldo del sistema solare?',
      options: ['Venere', 'Mercurio', 'Marte', 'Giove'],
      correct: 0,
      explanation: 'Venere è il pianeta più caldo del sistema solare a causa del suo denso effetto serra, con temperature superficiali di circa 462°C.'
    },
    {
      question: 'Cosa sono gli anelli di Saturno?',
      options: ['Detriti di ghiaccio e roccia', 'Gas compresso', 'Lune in orbita', 'Nubi di metano'],
      correct: 0,
      explanation: 'Gli anelli di Saturno sono composti principalmente da particelle di ghiaccio, roccia e polvere in orbita attorno al pianeta.'
    },
    {
      question: 'Quale è il più grande satellite naturale del sistema solare?',
      options: ['Ganimede', 'Luna', 'Titano', 'Europa'],
      correct: 0,
      explanation: 'Ganimede, una luna di Giove, è il più grande satellite naturale del sistema solare, più grande di Mercurio.'
    },
    {
      question: 'Cosa è la fascia di Kuiper?',
      options: ['Regione di oggetti ghiacciati oltre Nettuno', 'Anello di asteroidi', 'Nube di gas interstellare', 'Zona di radiazioni solari'],
      correct: 0,
      explanation: 'La fascia di Kuiper è una regione del sistema solare esterno che contiene numerosi oggetti ghiacciati, incluso Plutone.'
    },
    {
      question: 'Qual è il più grande vulcano del sistema solare?',
      options: ['Olympus Mons', 'Etna', 'Mauna Kea', 'Vesuvio'],
      correct: 0,
      explanation: 'Olympus Mons su Marte è il più grande vulcano conosciuto nel sistema solare, alto circa 21.9 km.'
    },
    {
      question: 'Cosa causa le stagioni sulla Terra?',
      options: ['L\'inclinazione dell\'asse terrestre', 'La distanza dal Sole', 'La rotazione terrestre', 'Le correnti oceaniche'],
      correct: 0,
      explanation: 'Le stagioni sono causate dall\'inclinazione dell\'asse terrestre di 23.5 gradi durante la rivoluzione intorno al Sole.'
    },
    {
      question: 'Cosa è un anno luce?',
      options: ['La distanza che la luce percorre in un anno', 'Il tempo che la luce impiega per raggiungere la Terra', 'La luminosità di una stella', 'La durata di un anno su altri pianeti'],
      correct: 0,
      explanation: 'Un anno luce è la distanza che la luce percorre in un anno, circa 9.46 trilioni di chilometri.'
    }
  ],
  [CATEGORIES.PHYSICS]: [
    {
      question: 'Qual è l\'unità di misura della forza nel Sistema Internazionale?',
      options: ['Newton', 'Joule', 'Watt', 'Pascal'],
      correct: 0,
      explanation: 'Il Newton (N) è l\'unità di misura della forza, equivalente a kg⋅m/s².'
    },
    {
      question: 'Quale particella ha carica positiva nel nucleo atomico?',
      options: ['Protone', 'Elettrone', 'Neutrone', 'Positrone'],
      correct: 0,
      explanation: 'Il protone ha carica positiva e si trova nel nucleo atomico insieme ai neutroni.'
    },
    {
      question: 'Quale è la velocità della luce nel vuoto?',
      options: ['299.792.458 m/s', '200.000.000 m/s', '150.000.000 m/s', '350.000.000 m/s'],
      correct: 0,
      explanation: 'La velocità della luce nel vuoto è esattamente 299.792.458 metri al secondo, una costante fondamentale della fisica.'
    },
    {
      question: 'Cosa afferma il Principio di Conservazione dell\'Energia?',
      options: ['L\'energia non può essere creata né distrutta', 'L\'energia può essere solo creata', 'L\'energia può essere solo distrutta', 'L\'energia rimane sempre costante'],
      correct: 0,
      explanation: 'Il Principio di Conservazione dell\'Energia afferma che l\'energia non può essere creata né distrutta, ma solo trasformata da una forma all\'altra.'
    },
    {
      question: 'Quale è l\'unità di misura della pressione nel SI?',
      options: ['Pascal', 'Bar', 'Atmosfera', 'PSI'],
      correct: 0,
      explanation: 'Il Pascal (Pa) è l\'unità di misura della pressione nel Sistema Internazionale, equivalente a N/m².'
    },
    {
      question: 'Cosa misura la scala Kelvin?',
      options: ['Temperatura assoluta', 'Pressione', 'Energia', 'Massa'],
      correct: 0,
      explanation: 'La scala Kelvin misura la temperatura assoluta, dove lo zero rappresenta lo zero assoluto (-273.15°C).'
    },
    {
      question: 'Quale legge di Newton descrive la relazione tra forza, massa e accelerazione?',
      options: ['Seconda legge', 'Prima legge', 'Terza legge', 'Legge di gravità'],
      correct: 0,
      explanation: 'La seconda legge di Newton (F = ma) stabilisce che la forza è uguale al prodotto della massa per l\'accelerazione.'
    },
    {
      question: 'Cosa sono le onde elettromagnetiche?',
      options: ['Oscillazioni di campi elettrici e magnetici', 'Onde sonore', 'Onde meccaniche', 'Onde di pressione'],
      correct: 0,
      explanation: 'Le onde elettromagnetiche sono oscillazioni di campi elettrici e magnetici che si propagano nello spazio, includono luce, radio, raggi X, etc.'
    },
    {
      question: 'Quale principio descrive il galleggiamento dei corpi?',
      options: ['Principio di Archimede', 'Principio di Pascal', 'Principio di Bernoulli', 'Principio di Torricelli'],
      correct: 0,
      explanation: 'Il Principio di Archimede afferma che un corpo immerso in un fluido riceve una spinta verso l\'alto pari al peso del fluido spostato.'
    },
    {
      question: 'Cosa afferma il Principio di Esclusione di Pauli?',
      options: ['Due elettroni non possono avere tutti i numeri quantici uguali', 'Gli elettroni sono sempre positivi', 'Gli elettroni sono sempre in coppia', 'Gli elettroni non possono esistere isolati'],
      correct: 0,
      explanation: 'Il Principio di Esclusione di Pauli stabilisce che due elettroni in un atomo non possono avere tutti i numeri quantici identici.'
    }
  ],
  [CATEGORIES.MATH]: [
    {
      question: 'Qual è il valore di π (pi greco) approssimato alle prime due cifre decimali?',
      options: ['3,14', '3,16', '3,12', '3,18'],
      correct: 0,
      explanation: 'π è approssimato a 3,14159... ed è il rapporto tra circonferenza e diametro del cerchio.'
    },
    {
      question: 'Come si chiama un poligono con 8 lati?',
      options: ['Ottagono', 'Ettagono', 'Ennagono', 'Decagono'],
      correct: 0,
      explanation: 'L\'ottagono è un poligono regolare con 8 lati e 8 angoli.'
    },
    {
      question: 'Cosa è il teorema di Pitagora?',
      options: ['a² + b² = c²', 'a + b = c', 'a × b = c', 'a - b = c'],
      correct: 0,
      explanation: 'Il teorema di Pitagora stabilisce che in un triangolo rettangolo, il quadrato dell\'ipotenusa (c) è uguale alla somma dei quadrati dei cateti (a e b).'
    },
    {
      question: 'Quale è il più piccolo numero primo?',
      options: ['2', '1', '0', '3'],
      correct: 0,
      explanation: '2 è il più piccolo numero primo e l\'unico numero primo pari.'
    },
    {
      question: 'Come si chiama il punto di intersezione delle mediane di un triangolo?',
      options: ['Baricentro', 'Ortocentro', 'Incentro', 'Circocentro'],
      correct: 0,
      explanation: 'Il baricentro è il punto di intersezione delle mediane di un triangolo e rappresenta il suo centro di massa.'
    },
    {
      question: 'Cosa è un numero palindromo?',
      options: ['Si legge uguale da sinistra a destra e viceversa', 'È divisibile per 2', 'È la somma di due numeri primi', 'È un numero negativo'],
      correct: 0,
      explanation: 'Un numero palindromo, come 121 o 12321, si legge allo stesso modo da sinistra a destra e da destra a sinistra.'
    },
    {
      question: 'Qual è il risultato di qualsiasi numero elevato a zero?',
      options: ['1', '0', 'Il numero stesso', 'Infinito'],
      correct: 0,
      explanation: 'Qualsiasi numero (eccetto 0) elevato a zero dà come risultato 1.'
    },
    {
      question: 'Cosa è la sezione aurea?',
      options: ['Un rapporto circa uguale a 1,618', 'Un angolo di 90 gradi', 'Il rapporto tra base e altezza', 'La metà di un cerchio'],
      correct: 0,
      explanation: 'La sezione aurea è un rapporto speciale, circa 1,618, considerato particolarmente piacevole esteticamente e presente in natura.'
    },
    {
      question: 'Come si chiama un poligono con un numero infinito di lati?',
      options: ['Cerchio', 'Triangolo', 'Quadrato', 'Pentagono'],
      correct: 0,
      explanation: 'Un poligono con un numero infinito di lati può essere considerato un cerchio.'
    },
    {
      question: 'Quale è il risultato di 0! (zero fattoriale)?',
      options: ['1', '0', 'Infinito', 'Non definito'],
      correct: 0,
      explanation: 'Per definizione, 0! è uguale a 1, questa convenzione è utile in molte formule matematiche.'
    }
  ],
  [CATEGORIES.MARINE_BIOLOGY]: [
    {
      question: 'Qual è l\'animale più grande del mondo?',
      options: ['Balenottera azzurra', 'Capodoglio', 'Squalo bianco', 'Orca'],
      correct: 0,
      explanation: 'La balenottera azzurra è l\'animale più grande mai esistito, può raggiungere i 30 metri di lunghezza.'
    },
    {
      question: 'A quale profondità si trova la Fossa delle Marianne?',
      options: ['11.000 metri', '8.000 metri', '5.000 metri', '15.000 metri'],
      correct: 0,
      explanation: 'La Fossa delle Marianne raggiunge una profondità di circa 11.000 metri, il punto più profondo degli oceani.'
    },
    {
      question: 'Quale fenomeno permette ai pesci di regolare la loro profondità nell\'acqua?',
      options: ['Vescica natatoria', 'Pinne laterali', 'Branchie', 'Scaglie'],
      correct: 0,
      explanation: 'La vescica natatoria è un organo che permette ai pesci di regolare il loro galleggiamento modificando la quantità di gas al suo interno.'
    },
    {
      question: 'Quale è il più grande pesce del mondo?',
      options: ['Squalo balena', 'Squalo bianco', 'Marlin', 'Tonno rosso'],
      correct: 0,
      explanation: 'Lo squalo balena può raggiungere i 12 metri di lunghezza ed è il più grande pesce esistente, nonostante si nutra principalmente di plancton.'
    },
    {
      question: 'Come si chiama il fenomeno di emissione di luce da parte di organismi marini?',
      options: ['Bioluminescenza', 'Fosforescenza', 'Fluorescenza', 'Riflessione'],
      correct: 0,
      explanation: 'La bioluminescenza è la capacità di alcuni organismi marini di produrre luce attraverso reazioni chimiche.'
    },
    {
      question: 'Quale gruppo di animali marini include le meduse?',
      options: ['Cnidari', 'Molluschi', 'Crostacei', 'Echinodermi'],
      correct: 0,
      explanation: 'I Cnidari includono meduse, anemoni e coralli, caratterizzati dalla presenza di cellule urticanti chiamate cnidociti.'
    },
    {
      question: 'Quale è la funzione principale della barriera corallina?',
      options: ['Ecosistema per migliaia di specie', 'Produzione di ossigeno', 'Assorbimento di CO2', 'Regolazione delle maree'],
      correct: 0,
      explanation: 'Le barriere coralline sono ecosistemi cruciali che forniscono habitat a circa il 25% di tutte le specie marine conosciute.'
    },
    {
      question: 'Come respirano i mammiferi marini?',
      options: ['Polmoni', 'Branchie', 'Pelle', 'Tentacoli'],
      correct: 0,
      explanation: 'I mammiferi marini, come balene e delfini, respirano attraverso i polmoni e devono emergere periodicamente per respirare aria.'
    },
    {
      question: 'Quale adattamento permette ai pinguini di sopravvivere in acque fredde?',
      options: ['Strato di grasso e piume impermeabili', 'Sangue caldo', 'Scaglie protettive', 'Membrane tra le dita'],
      correct: 0,
      explanation: 'I pinguini hanno uno spesso strato di grasso sottocutaneo e piume impermeabili sovrapposte che li isolano dall\'acqua fredda.'
    },
    {
      question: 'Quale è il principale predatore degli oceani?',
      options: ['Orca', 'Squalo bianco', 'Calamaro gigante', 'Barracuda'],
      correct: 0,
      explanation: 'L\'orca è considerata il principale predatore degli oceani, capace di cacciare anche altri predatori come squali e foche.'
    }
  ],
  [CATEGORIES.BIOLOGY]: [
    {
      question: 'Qual è l\'unità base della vita?',
      options: ['Cellula', 'Molecola', 'Atomo', 'Tessuto'],
      correct: 0,
      explanation: 'La cellula è l\'unità fondamentale degli organismi viventi, capace di auto-mantenersi e riprodursi.'
    },
    {
      question: 'Quale organo è responsabile della produzione di insulina?',
      options: ['Pancreas', 'Fegato', 'Reni', 'Milza'],
      correct: 0,
      explanation: 'Il pancreas produce l\'insulina, l\'ormone che regola i livelli di glucosio nel sangue.'
    },
    {
      question: 'Cosa sono i mitocondri?',
      options: ['Centrali energetiche della cellula', 'Depositi di acqua', 'Strutture di movimento', 'Sistemi di difesa'],
      correct: 0,
      explanation: 'I mitocondri sono organelli cellulari responsabili della produzione di energia attraverso la respirazione cellulare.'
    },
    {
      question: 'Quale processo utilizzano le piante per produrre il proprio nutrimento?',
      options: ['Fotosintesi', 'Respirazione', 'Fermentazione', 'Digestione'],
      correct: 0,
      explanation: 'La fotosintesi è il processo attraverso cui le piante convertono luce solare, acqua e anidride carbonica in glucosio e ossigeno.'
    },
    {
      question: 'Cosa è il DNA?',
      options: ['Acido nucleico che contiene informazioni genetiche', 'Proteina strutturale', 'Enzima digestivo', 'Ormone'],
      correct: 0,
      explanation: 'Il DNA (acido deossiribonucleico) è la molecola che contiene le informazioni genetiche necessarie per lo sviluppo e il funzionamento degli organismi.'
    },
    {
      question: 'Quale è la funzione principale dei globuli rossi?',
      options: ['Trasporto di ossigeno', 'Difesa immunitaria', 'Coagulazione', 'Produzione di ormoni'],
      correct: 0,
      explanation: 'I globuli rossi trasportano ossigeno dai polmoni ai tessuti attraverso l\'emoglobina.'
    },
    {
      question: 'Come si chiama il processo di divisione cellulare?',
      options: ['Mitosi', 'Osmosi', 'Diffusione', 'Sintesi'],
      correct: 0,
      explanation: 'La mitosi è il processo di divisione cellulare che produce due cellule figlie identiche.'
    },
    {
      question: 'Quale è l\'organo più grande del corpo umano?',
      options: ['Pelle', 'Fegato', 'Intestino', 'Polmoni'],
      correct: 0,
      explanation: 'La pelle è l\'organo più grande del corpo umano, con una superficie di circa 2 metri quadrati in un adulto.'
    },
    {
      question: 'Cosa sono gli anticorpi?',
      options: ['Proteine del sistema immunitario', 'Batteri benefici', 'Globuli rossi', 'Ormoni'],
      correct: 0,
      explanation: 'Gli anticorpi sono proteine prodotte dal sistema immunitario per identificare e neutralizzare sostanze estranee come batteri e virus.'
    },
    {
      question: 'Quale è la funzione principale del sistema linfatico?',
      options: ['Difesa immunitaria e drenaggio dei fluidi', 'Digestione del cibo', 'Produzione di ormoni', 'Controllo della temperatura'],
      correct: 0,
      explanation: 'Il sistema linfatico è fondamentale per la difesa immunitaria e il drenaggio dei fluidi in eccesso dai tessuti.'
    }
  ],
  [CATEGORIES.HISTORY]: [
    {
      question: 'In quale anno è caduto l\'Impero Romano d\'Occidente?',
      options: ['476 d.C.', '410 d.C.', '500 d.C.', '455 d.C.'],
      correct: 0,
      explanation: 'L\'Impero Romano d\'Occidente cadde nel 476 d.C. quando Odoacre depose l\'ultimo imperatore Romolo Augustolo.'
    },
    {
      question: 'Chi era il leader dell\'Unione Sovietica durante la Crisi dei Missili di Cuba?',
      options: ['Nikita Krusciov', 'Joseph Stalin', 'Lenin', 'Leonid Breznev'],
      correct: 0,
      explanation: 'Nikita Krusciov era il leader dell\'URSS durante la Crisi dei Missili di Cuba del 1962.'
    },
    {
      question: 'Quale evento ha dato inizio alla Prima Guerra Mondiale?',
      options: ['L\'assassinio dell\'arciduca Francesco Ferdinando', 'L\'invasione della Polonia', 'La Rivoluzione Russa', 'Il Patto di Monaco'],
      correct: 0,
      explanation: 'L\'assassinio dell\'arciduca Francesco Ferdinando a Sarajevo nel 1914 fu la scintilla che diede inizio alla Prima Guerra Mondiale.'
    },
    {
      question: 'Chi era il primo re dell\'Italia unita?',
      options: ['Vittorio Emanuele II', 'Umberto I', 'Carlo Alberto', 'Vittorio Emanuele III'],
      correct: 0,
      explanation: 'Vittorio Emanuele II di Savoia fu il primo re dell\'Italia unita, regnando dal 1861 al 1878.'
    },
    {
      question: 'In quale anno è stato abbattuto il Muro di Berlino?',
      options: ['1989', '1991', '1985', '1987'],
      correct: 0,
      explanation: 'Il Muro di Berlino è stato abbattuto nel 1989, segnando la fine della divisione tra Germania Est e Ovest.'
    },
    {
      question: 'Chi era il faraone per cui fu costruita la più grande piramide di Giza?',
      options: ['Cheope', 'Tutankhamon', 'Ramses II', 'Cleopatra'],
      correct: 0,
      explanation: 'La Grande Piramide di Giza fu costruita come tomba per il faraone Cheope della IV dinastia.'
    },
    {
      question: 'Quale civiltà ha inventato la scrittura cuneiforme?',
      options: ['Sumeri', 'Egizi', 'Babilonesi', 'Assiri'],
      correct: 0,
      explanation: 'I Sumeri svilupparono la scrittura cuneiforme intorno al 3200 a.C. in Mesopotamia.'
    },
    {
      question: 'Chi era l\'imperatore romano durante l\'eruzione del Vesuvio che distrusse Pompei?',
      options: ['Tito', 'Nerone', 'Vespasiano', 'Domiziano'],
      correct: 0,
      explanation: 'L\'eruzione del Vesuvio del 79 d.C. avvenne durante il regno dell\'imperatore Tito.'
    },
    {
      question: 'Quale battaglia segnò la fine di Napoleone Bonaparte?',
      options: ['Waterloo', 'Austerlitz', 'Lipsia', 'Borodino'],
      correct: 0,
      explanation: 'La battaglia di Waterloo nel 1815 segnò la sconfitta definitiva di Napoleone Bonaparte.'
    },
    {
      question: 'In quale anno Cristoforo Colombo scoprì l\'America?',
      options: ['1492', '1489', '1495', '1498'],
      correct: 0,
      explanation: 'Cristoforo Colombo giunse nelle Americhe il 12 ottobre 1492.'
    },
    {
      question: 'Chi era il re di Francia durante la Rivoluzione Francese?',
      options: ['Luigi XVI', 'Luigi XIV', 'Luigi XV', 'Carlo X'],
      correct: 0,
      explanation: 'Luigi XVI era il re di Francia durante la Rivoluzione Francese e fu ghigliottinato nel 1793.'
    },
    {
      question: 'Quale città fu la capitale dell\'Impero Romano d\'Oriente?',
      options: ['Costantinopoli', 'Roma', 'Atene', 'Alessandria'],
      correct: 0,
      explanation: 'Costantinopoli (oggi Istanbul) fu la capitale dell\'Impero Romano d\'Oriente o Impero Bizantino.'
    }
  ],
  [CATEGORIES.ART_HISTORY]: [
    {
      question: 'Chi ha dipinto la Gioconda?',
      options: ['Leonardo da Vinci', 'Michelangelo', 'Raffaello', 'Botticelli'],
      correct: 0,
      explanation: 'La Gioconda o Monna Lisa è stata dipinta da Leonardo da Vinci tra il 1503 e il 1506.'
    },
    {
      question: 'Quale movimento artistico è stato fondato da Claude Monet?',
      options: ['Impressionismo', 'Cubismo', 'Surrealismo', 'Espressionismo'],
      correct: 0,
      explanation: 'L\'Impressionismo è nato in Francia nel XIX secolo, con Claude Monet come uno dei suoi principali esponenti.'
    },
    {
      question: 'Chi ha scolpito il David?',
      options: ['Michelangelo', 'Donatello', 'Bernini', 'Rodin'],
      correct: 0,
      explanation: 'Il David è stato scolpito da Michelangelo Buonarroti tra il 1501 e il 1504.'
    },
    {
      question: 'Quale artista è famoso per aver tagliato il proprio orecchio?',
      options: ['Vincent van Gogh', 'Pablo Picasso', 'Salvador Dalì', 'Claude Monet'],
      correct: 0,
      explanation: 'Vincent van Gogh si tagliò parte dell\'orecchio sinistro durante una crisi nel 1888.'
    },
    {
      question: 'Chi ha dipinto "La Notte Stellata"?',
      options: ['Vincent van Gogh', 'Edgar Degas', 'Paul Gauguin', 'Pierre-Auguste Renoir'],
      correct: 0,
      explanation: '"La Notte Stellata" è stata dipinta da Vincentvan Gogh nel 1889 durante il suo soggiorno all\'asilo di Saint-Rémy-de-Provence.'
    },
    {
      question: 'Quale artista è conosciuto per i suoi orologi molli?',
      options: ['Salvador Dalì', 'René Magritte', 'Joan Miró', 'Max Ernst'],
      correct: 0,
      explanation: 'Gli orologi molli appaiono nel famoso dipinto "La persistenza della memoria" di Salvador Dalì del 1931.'
    },
    {
      question: 'Chi ha affrescato la Cappella Sistina?',
      options: ['Michelangelo', 'Raffaello', 'Leonardo da Vinci', 'Botticelli'],
      correct: 0,
      explanation: 'Michelangelo dipinse gli affreschi della Cappella Sistina tra il 1508 e il 1512.'
    },
    {
      question: 'Quale artista è considerato il padre del Cubismo?',
      options: ['Pablo Picasso', 'Georges Braque', 'Henri Matisse', 'Paul Cézanne'],
      correct: 0,
      explanation: 'Pablo Picasso, insieme a Georges Braque, è considerato il fondatore del movimento cubista.'
    },
    {
      question: 'Chi ha dipinto "L\'urlo"?',
      options: ['Edvard Munch', 'Gustav Klimt', 'Wassily Kandinsky', 'Paul Klee'],
      correct: 0,
      explanation: '"L\'urlo" è stato dipinto da Edvard Munch nel 1893, diventando un\'icona dell\'arte espressionista.'
    },
    {
      question: 'Quale artista è famoso per i suoi "Campbell\'s Soup Cans"?',
      options: ['Andy Warhol', 'Roy Lichtenstein', 'Keith Haring', 'Jean-Michel Basquiat'],
      correct: 0,
      explanation: 'Andy Warhol creò le "Campbell\'s Soup Cans" nel 1962, un\'opera iconica della Pop Art.'
    },
    {
      question: 'Chi ha dipinto la "Nascita di Venere"?',
      options: ['Sandro Botticelli', 'Tiziano', 'Giorgione', 'Caravaggio'],
      correct: 0,
      explanation: 'La "Nascita di Venere" è stata dipinta da Sandro Botticelli intorno al 1485.'
    },
    {
      question: 'Quale artista è noto per aver dipinto "La persistenza della memoria"?',
      options: ['Salvador Dalì', 'René Magritte', 'Frida Kahlo', 'Max Ernst'],
      correct: 0,
      explanation: '"La persistenza della memoria" con i suoi orologi molli è un\'opera surrealista di Salvador Dalì del 1931.'
    }
  ]
};

const quizGame = async (message, args) => {
  if (args.length !== 2) {
    let categories = Object.values(CATEGORIES).map((cat, i) => `${i + 1}. ${cat}`).join('\n');
    return message.reply(`🎯 Quiz Game 🎯\n\nUso: !quiz <numero_categoria> <puntata>\n\nCategorie disponibili:\n${categories}\n\nEsempio: !quiz 1 1000 per giocare nella categoria Natale`);
  }

  const categoryIndex = parseInt(args[0]) - 1;
  const bet = parseInt(args[1]);

  if (isNaN(categoryIndex) || categoryIndex < 0 || categoryIndex >= Object.keys(CATEGORIES).length) {
    let categories = Object.values(CATEGORIES).map((cat, i) => `${i + 1}. ${cat}`).join('\n');
    return message.reply(`❌ Categoria non valida!\n\nCategorie disponibili:\n${categories}`);
  }

  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const category = Object.values(CATEGORIES)[categoryIndex];
  const questions = QUIZ_QUESTIONS[category];
  const question = questions[Math.floor(Math.random() * questions.length)];

  const options = question.options.map((opt, i) => `${i + 1}. ${opt}`).join('\n');
  message.reply(`📚 Quiz di ${category}\n\nDomanda: ${question.question}\n\n${options}\n\nRispondi con un numero da 1 a ${question.options.length}`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= question.options.length;

  try {
    const collected = await message.channel.awaitMessages({ 
      filter, 
      max: 1, 
      time: 30000 
    });

    const answer = parseInt(collected.first().content) - 1;
    const correct = answer === question.correct;

    if (correct) {
      const win = bet * 2;
      addBudget(message.author.id, win);
      message.reply(`✅ Corretto! ${question.explanation}\n\nHai vinto €${win.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
    } else {
      addBudget(message.author.id, -bet);
      message.reply(`❌ Sbagliato! La risposta corretta era: ${question.options[question.correct]}\n${question.explanation}\n\nHai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
    }
  } catch (error) {
    message.reply('⏰ Tempo scaduto!');
  }
};

module.exports = { quizGame };