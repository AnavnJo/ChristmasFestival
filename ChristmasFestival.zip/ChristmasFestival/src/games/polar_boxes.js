const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const ANIMALS = {
  'Orso Polare': '🐻‍❄️',
  'Pinguino': '🐧',
  'Volpe Artica': '🦊',
  'Foca': '🦭',
  'Renna': '🦌',
  'Gufo delle Nevi': '🦉',
  'Balena': '🐋',
  'Tricheco': '🦭'
};

class PolarBox {
  constructor(id, animal, prize) {
    this.id = id;
    this.animal = animal;
    this.prize = prize;
    this.isOpen = false;
  }
}

const polarBoxGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !pacchi <puntata>\nEsempio: !pacchi 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  // Create boxes with random prizes and animals
  const boxes = [];
  const prizes = [
    bet * 0.5, bet, bet * 1.5, bet * 2, bet * 2.5,
    bet * 3, bet * 3.5, bet * 4, bet * 4.5, bet * 5,
    bet * -0.5, bet * -1, bet * -1.5, bet * -2, bet * -2.5,
    bet * 10, bet * -5, bet * 7, bet * -3, bet * 15
  ];
  
  const animalEntries = Object.entries(ANIMALS);
  for (let i = 0; i < 20; i++) {
    const animal = animalEntries[Math.floor(Math.random() * animalEntries.length)];
    boxes.push(new PolarBox(i + 1, animal, prizes[i]));
  }

  const displayBoxes = () => {
    let display = '📦 Pacchi del Polo Nord 📦\n\n';
    boxes.forEach(box => {
      if (box.isOpen) {
        display += `${box.animal[1]} `;
      } else {
        display += `${box.id}️⃣ `;
      }
      if (box.id % 5 === 0) display += '\n';
    });
    return display;
  };

  message.reply(`${displayBoxes()}\nScegli un numero da 1 a 20 per aprire un pacco!`);

  let openedBoxes = 0;
  const maxOpens = 3;

  while (openedBoxes < maxOpens) {
    try {
      const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                         parseInt(m.content) >= 1 && parseInt(m.content) <= 20;
      
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const choice = parseInt(collected.first().content) - 1;
      
      if (boxes[choice].isOpen) {
        message.reply('Questo pacco è già stato aperto! Scegline un altro.');
        continue;
      }

      boxes[choice].isOpen = true;
      openedBoxes++;

      const prize = boxes[choice].prize;
      const animal = boxes[choice].animal;

      let resultMessage = `Hai trovato un ${animal[0]} ${animal[1]}!\n`;
      if (prize > 0) {
        resultMessage += `🎉 Hai vinto €${prize.toLocaleString()}!`;
      } else {
        resultMessage += `😢 Hai perso €${Math.abs(prize).toLocaleString()}!`;
      }

      addBudget(message.author.id, prize);
      resultMessage += `\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}\n\n`;

      if (openedBoxes < maxOpens) {
        resultMessage += `Puoi aprire ancora ${maxOpens - openedBoxes} pacchi!\n`;
      }

      message.reply(`${resultMessage}${displayBoxes()}`);

    } catch (error) {
      return message.reply('⏰ Tempo scaduto! I pacchi sono stati portati via!');
    }
  }

  message.reply('🎮 Game Over! Hai aperto tutti i pacchi disponibili!');
};

module.exports = { polarBoxGame };
