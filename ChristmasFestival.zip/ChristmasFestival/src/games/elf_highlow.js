const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const MAX_ELVES = 100;
const MAX_ATTEMPTS = 5;

const elfHighLow = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !elfi <puntata>\nEsempio: !elfi 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const elfCount = Math.floor(Math.random() * MAX_ELVES) + 1;
  let attempts = MAX_ATTEMPTS;

  message.reply(`🧝 Gli elfi stanno scappando con la slitta dei regali! 🛷\nIndovina quanti elfi ci sono (1-${MAX_ELVES})\nHai ${attempts} tentativi per indovinare!`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= MAX_ELVES;

  while (attempts > 0) {
    try {
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const guess = parseInt(collected.first().content);
      attempts--;

      if (guess === elfCount) {
        const win = bet * (MAX_ATTEMPTS - attempts);
        addBudget(message.author.id, win);
        return message.reply(`🎉 Incredibile! Hai indovinato! Erano proprio ${elfCount} elfi!\nHai vinto €${win.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      } else {
        const hint = guess > elfCount ? 'meno' : 'più';
        if (attempts > 0) {
          message.reply(`Gli elfi sono ${hint} di ${guess}! Ti rimangono ${attempts} tentativi.`);
        }
      }
    } catch (error) {
      return message.reply('⏰ Tempo scaduto! Gli elfi sono scappati!');
    }
  }

  addBudget(message.author.id, -bet);
  message.reply(`Game over! Gli elfi erano ${elfCount}!\nHai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
};

module.exports = { elfHighLow };
