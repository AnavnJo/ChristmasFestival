const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

class TrisGame {
  constructor() {
    this.board = Array(9).fill(' ');
    this.winningCombos = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // righe
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // colonne
      [0, 4, 8], [2, 4, 6] // diagonali
    ];
  }

  makeMove(position, symbol) {
    if (position < 0 || position > 8 || this.board[position] !== ' ') {
      return false;
    }
    this.board[position] = symbol;
    return true;
  }

  getBotMove() {
    // Strategia del bot:
    // 1. Vinci se possibile
    // 2. Blocca la vittoria dell'avversario
    // 3. Prendi il centro se libero
    // 4. Prendi un angolo se libero
    // 5. Prendi qualsiasi casella libera

    // Controlla possibilità di vittoria
    const moveForWin = this.findWinningMove('O');
    if (moveForWin !== -1) return moveForWin;

    // Blocca vittoria avversario
    const blockMove = this.findWinningMove('X');
    if (blockMove !== -1) return blockMove;

    // Prendi il centro
    if (this.board[4] === ' ') return 4;

    // Prendi un angolo
    const corners = [0, 2, 6, 8];
    const emptyCorners = corners.filter(i => this.board[i] === ' ');
    if (emptyCorners.length > 0) {
      return emptyCorners[Math.floor(Math.random() * emptyCorners.length)];
    }

    // Prendi qualsiasi casella libera
    const emptyCells = this.board.map((cell, i) => cell === ' ' ? i : null).filter(i => i !== null);
    return emptyCells[Math.floor(Math.random() * emptyCells.length)];
  }

  findWinningMove(symbol) {
    for (let i = 0; i < 9; i++) {
      if (this.board[i] === ' ') {
        this.board[i] = symbol;
        if (this.checkWin(symbol)) {
          this.board[i] = ' ';
          return i;
        }
        this.board[i] = ' ';
      }
    }
    return -1;
  }

  checkWin(symbol) {
    return this.winningCombos.some(combo => 
      combo.every(pos => this.board[pos] === symbol)
    );
  }

  isBoardFull() {
    return !this.board.includes(' ');
  }

  displayBoard() {
    let display = '```\n';
    for (let i = 0; i < 9; i += 3) {
      display += ` ${this.board[i] || ' '} │ ${this.board[i + 1] || ' '} │ ${this.board[i + 2] || ' '} \n`;
      if (i < 6) display += '───┼───┼───\n';
    }
    display += '```\n';
    display += 'Posizioni:\n```\n';
    for (let i = 0; i < 9; i += 3) {
      display += ` ${i + 1} │ ${i + 2} │ ${i + 3} \n`;
      if (i < 6) display += '───┼───┼───\n';
    }
    display += '```';
    return display;
  }
}

const trisGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !tris <puntata>\nEsempio: !tris 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const game = new TrisGame();
  message.reply(`
🎮 Tris - Tu sei X, il bot è O

${game.displayBoard()}

Scegli una posizione (1-9):`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= 9;

  while (!game.isBoardFull() && !game.checkWin('X') && !game.checkWin('O')) {
    try {
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const position = parseInt(collected.first().content) - 1;
      if (!game.makeMove(position, 'X')) {
        message.reply('Posizione non valida o già occupata! Riprova.');
        continue;
      }

      if (game.checkWin('X')) {
        const win = bet * 2;
        addBudget(message.author.id, win);
        return message.reply(`
🎉 Hai vinto!

${game.displayBoard()}

Hai vinto €${win.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      }

      if (game.isBoardFull()) {
        return message.reply(`
🤝 Pareggio!

${game.displayBoard()}

La puntata ti viene restituita.`);
      }

      // Turno del bot
      const botMove = game.getBotMove();
      game.makeMove(botMove, 'O');

      if (game.checkWin('O')) {
        addBudget(message.author.id, -bet);
        return message.reply(`
😢 Hai perso!

${game.displayBoard()}

Hai perso €${bet.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      }

      message.reply(`
🤖 Il bot ha scelto la posizione ${botMove + 1}

${game.displayBoard()}

Scegli una posizione (1-9):`);

    } catch (error) {
      return message.reply('⏰ Tempo scaduto! Partita annullata.');
    }
  }
};

module.exports = { trisGame };
