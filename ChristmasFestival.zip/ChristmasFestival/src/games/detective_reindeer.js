const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const CASI = {
  FURTO: {
    tipo: 'Furto 🎁',
    difficolta: 1,
    moltiplicatore: 2
  },
  RAPINA: {
    tipo: 'Rapina 💰',
    difficolta: 2,
    moltiplicatore: 3
  },
  RISCATTO: {
    tipo: 'Riscatto 📜',
    difficolta: 3,
    moltiplicatore: 4
  },
  AGGRESSIONE: {
    tipo: 'Aggressione 👊',
    difficolta: 2,
    moltiplicatore: 3
  },
  TRUFFA: {
    tipo: 'Truffa 🎭',
    difficolta: 2,
    moltiplicatore: 3
  },
  OMICIDIO: {
    tipo: 'Omicidio 🔪',
    difficolta: 4,
    moltiplicatore: 5
  }
};

const PERSONAGGI = [
  { nome: 'Elfo Dispettoso', alibi: false, indizi: ['Impronte di scarpe piccole', 'Glitter verde', 'Risatina maliziosa'] },
  { nome: 'Yeti delle Nevi', alibi: true, indizi: ['Pelliccia bianca', 'Impronte giganti', 'Grotta ghiacciata'] },
  { nome: 'Goblin del Ghiaccio', alibi: false, indizi: ['Cristalli di ghiaccio', 'Artigli affilati', 'Monete rubate'] },
  { nome: 'Pinguino Sospetto', alibi: true, indizi: ['Piume nere', 'Impronte di zampe', 'Pesce fresco'] },
  { nome: 'Folletto Ladro', alibi: false, indizi: ['Cappello magico', 'Polvere dorata', 'Chiavi rubate'] },
  { nome: 'Orso Polare', alibi: true, indizi: ['Graffi sulla porta', 'Pelo bianco', 'Pesce mangiato'] },
  { nome: 'Strega della Neve', alibi: false, indizi: ['Scopa volante', 'Pozione misteriosa', 'Formula magica'] },
  { nome: 'Troll di Montagna', alibi: true, indizi: ['Rocce spostate', 'Muschio verde', 'Grotta abitata'] }
];

class CasoNatalizio {
  constructor(tipo) {
    this.tipo = CASI[tipo];
    this.indizi = [];
    this.sospetti = this.generaSospetti();
    this.colpevole = this.sospetti.find(s => !s.alibi);
    this.tentativi = 3;
    this.indiziRivelati = 0;
  }

  generaSospetti() {
    const numSospetti = 3 + this.tipo.difficolta;
    const sospetti = [...PERSONAGGI]
      .sort(() => Math.random() - 0.5)
      .slice(0, numSospetti);
    
    return sospetti;
  }

  rivelaIndizio() {
    if (this.indiziRivelati >= this.colpevole.indizi.length) {
      return null;
    }
    return this.colpevole.indizi[this.indiziRivelati++];
  }

  accusaSospetto(nomeSospetto) {
    this.tentativi--;
    const sospetto = this.sospetti.find(s => s.nome === nomeSospetto);
    return sospetto === this.colpevole;
  }

  getSospetti() {
    return this.sospetti.map(s => s.nome);
  }

  getStato() {
    return {
      tipo: this.tipo.tipo,
      tentativi: this.tentativi,
      indiziScoperti: this.indiziRivelati,
      moltiplicatore: this.tipo.moltiplicatore
    };
  }
}

const detectiveReindeerGame = async (message, args) => {
  if (args.length !== 2) {
    const tipiCasi = Object.keys(CASI).map(k => `${CASI[k].tipo} (x${CASI[k].moltiplicatore})`).join('\n');
    return message.reply(`
🦌 Detective Renna Cometa 🔍

Uso: !detective <tipo_caso> <puntata>

Casi disponibili:
${tipiCasi}

Esempio: !detective FURTO 1000
    `);
  }

  const [tipo, puntataStr] = args;
  const puntata = parseInt(puntataStr);

  if (!CASI[tipo.toUpperCase()]) {
    return message.reply('Tipo di caso non valido! Usa uno dei tipi elencati nel comando di aiuto.');
  }

  if (isNaN(puntata) || puntata < MIN_BET || puntata > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (puntata > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const caso = new CasoNatalizio(tipo.toUpperCase());
  message.reply(`
🔍 Nuovo Caso: ${caso.tipo.tipo}

Un crimine è stato commesso al Polo Nord! Babbo Natale ha bisogno del tuo aiuto per risolverlo.

Sospetti:
${caso.getSospetti().map((nome, i) => `${i + 1}. ${nome}`).join('\n')}

Primo indizio: ${caso.rivelaIndizio()}

Hai ${caso.tentativi} tentativi per identificare il colpevole.
Usa !indizio per rivelare un nuovo indizio
Usa !accusa <numero_sospetto> per accusare un sospetto

Vincita potenziale: €${(puntata * caso.tipo.moltiplicatore).toLocaleString()}
  `);

  const filter = m => m.author.id === message.author.id && 
                     (m.content.startsWith('!indizio') || m.content.startsWith('!accusa'));

  while (caso.tentativi > 0) {
    try {
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const comando = collected.first().content;
      
      if (comando === '!indizio') {
        const nuovoIndizio = caso.rivelaIndizio();
        if (nuovoIndizio) {
          message.reply(`
🔍 Nuovo indizio scoperto: ${nuovoIndizio}

Sospetti:
${caso.getSospetti().map((nome, i) => `${i + 1}. ${nome}`).join('\n')}

Tentativi rimasti: ${caso.tentativi}
          `);
        } else {
          message.reply('Non ci sono più indizi da rivelare!');
        }
        continue;
      }

      if (comando.startsWith('!accusa')) {
        const numeroSospetto = parseInt(comando.split(' ')[1]) - 1;
        if (isNaN(numeroSospetto) || numeroSospetto < 0 || numeroSospetto >= caso.getSospetti().length) {
          message.reply('Numero sospetto non valido!');
          continue;
        }

        const nomeSospetto = caso.getSospetti()[numeroSospetto];
        const successo = caso.accusaSospetto(nomeSospetto);

        if (successo) {
          const moltiplicatore = caso.tipo.moltiplicatore + (caso.tentativi * 0.5);
          const vincita = Math.floor(puntata * moltiplicatore);
          addBudget(message.author.id, vincita);
          return message.reply(`
🎉 Congratulazioni! Hai identificato il colpevole: ${nomeSospetto}

Con ${caso.tentativi} tentativi rimasti, hai guadagnato un bonus!
Moltiplicatore finale: x${moltiplicatore}

Hai vinto €${vincita.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}
          `);
        } else {
          if (caso.tentativi > 0) {
            message.reply(`
❌ ${nomeSospetto} non è il colpevole!

Tentativi rimasti: ${caso.tentativi}
            `);
          } else {
            addBudget(message.author.id, -puntata);
            return message.reply(`
😢 Game Over! Il colpevole era ${caso.colpevole.nome}!

Hai perso €${puntata.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}
            `);
          }
        }
      }
    } catch (error) {
      return message.reply('⏰ Tempo scaduto! Partita annullata.');
    }
  }
};

module.exports = { detectiveReindeerGame };
