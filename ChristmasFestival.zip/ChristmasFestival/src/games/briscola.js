const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

// Definizione delle carte siciliane
const SEMI = {
  COPPE: { nome: 'Coppe', emoji: '🏆', simbolo: 'C' },
  BASTONI: { nome: 'Bastoni', emoji: '🏒', simbolo: 'B' },
  SPADE: { nome: 'Spade', emoji: '⚔️', simbolo: 'S' },
  DENARI: { nome: 'Denari', emoji: '💰', simbolo: 'D' }
};

const VALORI = {
  ASSO: { nome: 'Asso', valore: 11, rank: 1, simbolo: 'A', display: 'Asso' },
  TRE: { nome: 'Tre', valore: 9, rank: 2, simbolo: '3', display: 'Tre' },
  RE: { nome: 'Re', valore: 9, rank: 3, simbolo: 'R', display: 'Re' },
  CAVALLO: { nome: 'Cavallo', valore: 8, rank: 4, simbolo: 'C', display: 'Cavallo' },
  FANTE: { nome: 'Fante', valore: 7, rank: 5, simbolo: 'F', display: 'Fante' },
  SETTE: { nome: 'Sette', valore: 0, rank: 6, simbolo: '7', display: 'Sette' },
  SEI: { nome: 'Sei', valore: 0, rank: 7, simbolo: '6', display: 'Sei' },
  CINQUE: { nome: 'Cinque', valore: 0, rank: 8, simbolo: '5', display: 'Cinque' },
  QUATTRO: { nome: 'Quattro', valore: 0, rank: 9, simbolo: '4', display: 'Quattro' },
  DUE: { nome: 'Due', valore: 0, rank: 10, simbolo: '2', display: 'Due' }
};

class Carta {
  constructor(seme, valore) {
    this.seme = seme;
    this.valore = valore;
  }

  toString() {
    return `┌───────────┐\n│${this.valore.simbolo} ${this.seme.simbolo}       │\n│ ${this.seme.emoji}        │\n│ ${this.valore.display.padEnd(8)}│\n│ ${this.valore.valore}pt      │\n└───────────┘`;
  }

  getPunti() {
    return this.valore.valore;
  }

  getBattuta(altra, briscola) {
    if (altra.seme === this.seme) {
      return this.valore.rank < altra.valore.rank;
    }
    if (this.seme === briscola) return true;
    if (altra.seme === briscola) return false;
    return false;
  }
}

class Mazzo {
  constructor() {
    this.carte = [];
    for (const seme of Object.values(SEMI)) {
      for (const valore of Object.values(VALORI)) {
        this.carte.push(new Carta(seme, valore));
      }
    }
    this.mischia();
  }

  mischia() {
    for (let i = this.carte.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.carte[i], this.carte[j]] = [this.carte[j], this.carte[i]];
    }
  }

  pesca() {
    return this.carte.pop();
  }

  isEmpty() {
    return this.carte.length === 0;
  }
}

class Briscola {
  constructor() {
    this.mazzo = new Mazzo();
    this.briscola = this.mazzo.pesca();
    this.mazzo.carte.unshift(this.briscola);
    this.manoGiocatore = [this.mazzo.pesca(), this.mazzo.pesca(), this.mazzo.pesca()];
    this.manoBot = [this.mazzo.pesca(), this.mazzo.pesca(), this.mazzo.pesca()];
    this.presaGiocatore = [];
    this.presaBot = [];
  }

  giocaCarta(indice) {
    if (indice < 0 || indice >= this.manoGiocatore.length) return null;
    const carta = this.manoGiocatore[indice];
    this.manoGiocatore.splice(indice, 1);
    if (!this.mazzo.isEmpty()) {
      this.manoGiocatore.push(this.mazzo.pesca());
    }
    return carta;
  }

  giocaBot(cartaGiocatore = null) {
    let indiceBot = 0;
    if (cartaGiocatore) {
      for (let i = 0; i < this.manoBot.length; i++) {
        const carta = this.manoBot[i];
        if (carta.getBattuta(cartaGiocatore, this.briscola.seme)) {
          indiceBot = i;
          break;
        }
      }
    }

    const cartaBot = this.manoBot[indiceBot];
    this.manoBot.splice(indiceBot, 1);
    if (!this.mazzo.isEmpty()) {
      this.manoBot.push(this.mazzo.pesca());
    }
    return cartaBot;
  }

  assegnaPresa(cartaGiocatore, cartaBot) {
    if (cartaGiocatore.getBattuta(cartaBot, this.briscola.seme)) {
      this.presaGiocatore.push(cartaGiocatore, cartaBot);
      return true;
    } else {
      this.presaBot.push(cartaGiocatore, cartaBot);
      return false;
    }
  }

  getPuntiGiocatore() {
    return this.presaGiocatore.reduce((sum, carta) => sum + carta.getPunti(), 0);
  }

  getPuntiBot() {
    return this.presaBot.reduce((sum, carta) => sum + carta.getPunti(), 0);
  }

  isFinita() {
    return this.mazzo.isEmpty() && this.manoGiocatore.length === 0 && this.manoBot.length === 0;
  }

  getManoGiocatoreStr() {
    return this.manoGiocatore.map((carta, i) => `${i + 1}. ${carta.toString()}`).join('\n');
  }
}

const briscolaGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !briscola <puntata>\nEsempio: !briscola 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const game = new Briscola();

  message.reply(`
🎴 Briscola Siciliana 🎴

Briscola: 
${game.briscola.toString()}

Le tue carte:
${game.manoGiocatore.map((carta, i) => `${i + 1}. ${carta.toString()}`).join('\n')}

Scegli una carta (1-3) da giocare!`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= 3;

  while (!game.isFinita()) {
    try {
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const scelta = parseInt(collected.first().content) - 1;
      const cartaGiocatore = game.giocaCarta(scelta);
      if (!cartaGiocatore) {
        message.reply('Scelta non valida! Riprova.');
        continue;
      }

      const cartaBot = game.giocaBot(cartaGiocatore);
      const vittoriaTurno = game.assegnaPresa(cartaGiocatore, cartaBot);

      let status = `
📥 Hai giocato:
${cartaGiocatore.toString()}
🤖 Bot gioca:
${cartaBot.toString()}
${vittoriaTurno ? '✅ Hai preso!' : '❌ Presa del bot!'}

🏆 Punteggio:
Tu: ${game.getPuntiGiocatore()} punti
Bot: ${game.getPuntiBot()} punti
`;

      if (!game.isFinita()) {
        status += `
🎴 Le tue carte:
${game.manoGiocatore.map((carta, i) => `${i + 1}. ${carta.toString()}`).join('\n')}
Briscola:
${game.briscola.toString()}

Scegli una carta (1-3) da giocare!
`;
      }

      message.reply(status);

    } catch (error) {
      return message.reply('⏰ Tempo scaduto! Partita annullata.');
    }
  }

  const puntiGiocatore = game.getPuntiGiocatore();
  const puntiBot = game.getPuntiBot();

  if (puntiGiocatore > puntiBot) {
    const moltiplicatore = 1 + (puntiGiocatore - 60) / 60;
    const vincita = Math.floor(bet * moltiplicatore);
    addBudget(message.author.id, vincita);
    message.reply(`
🎉 Hai vinto! 
Punteggio finale:
Tu: ${puntiGiocatore} punti
Bot: ${puntiBot} punti

Hai vinto €${vincita.toLocaleString()}!
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}
    `);
  } else {
    addBudget(message.author.id, -bet);
    message.reply(`
😢 Hai perso! 
Punteggio finale:
Tu: ${puntiGiocatore} punti
Bot: ${puntiBot} punti

Hai perso €${bet.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}
    `);
  }
};

module.exports = { briscolaGame };