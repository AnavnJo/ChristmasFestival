const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const coinflip = async (message, args) => {
  if (args.length !== 2) {
    return message.reply('Uso: !coinflip <testa/croce> <puntata>\nEsempio: !coinflip testa 1000');
  }

  const choice = args[0].toLowerCase();
  const bet = parseInt(args[1]);

  if (choice !== 'testa' && choice !== 'croce') {
    return message.reply('Devi scegliere tra testa o croce!\nEsempio: !coinflip testa 1000');
  }

  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const result = Math.random() < 0.5 ? 'testa' : 'croce';
  const won = choice === result;

  if (won) {
    addBudget(message.author.id, bet);
    message.reply(`È uscito ${result}! 🎉 Hai vinto €${bet.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  } else {
    addBudget(message.author.id, -bet);
    message.reply(`È uscito ${result}! 😢 Hai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  }
};

module.exports = { coinflip };