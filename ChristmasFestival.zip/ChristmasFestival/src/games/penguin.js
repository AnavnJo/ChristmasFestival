const { MIN_BET, MAX_BET, GAMES } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const penguinGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !pinguino <puntata>');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET} e €${MAX_BET}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply('Non hai abbastanza fondi per questa puntata!');
  }

  const grid = Array(GAMES.PENGUIN.GRID_SIZE).fill('❄️');
  const luckyPenguin = Math.floor(Math.random() * GAMES.PENGUIN.GRID_SIZE);
  const polarBear = Math.floor(Math.random() * GAMES.PENGUIN.GRID_SIZE);

  const displayGrid = () => {
    let display = '';
    for (let i = 0; i < grid.length; i++) {
      display += `${grid[i]} `;
      if ((i + 1) % 3 === 0) display += '\n';
    }
    return display;
  };

  message.reply(`Trova il pinguino fortunato! Scegli un numero da 1 a ${GAMES.PENGUIN.GRID_SIZE}\n${displayGrid()}`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= GAMES.PENGUIN.GRID_SIZE;

  try {
    const collected = await message.channel.awaitMessages({ 
      filter, 
      max: 1, 
      time: 30000 
    });

    const choice = parseInt(collected.first().content) - 1;

    if (choice === polarBear) {
      grid[choice] = '🐻';
      const loss = Math.floor(bet * GAMES.PENGUIN.POLAR_BEAR_PENALTY);
      addBudget(message.author.id, -loss);
      message.reply(`Oh no! Hai trovato l'orso polare! Hai perso €${loss.toLocaleString()}!\n${displayGrid()}`);
    } else if (choice === luckyPenguin) {
      grid[choice] = '🐧';
      const win = bet * GAMES.PENGUIN.WIN_MULTIPLIER;
      addBudget(message.author.id, win);
      message.reply(`Congratulazioni! Hai trovato il pinguino fortunato! Hai vinto €${win.toLocaleString()}!\n${displayGrid()}`);
    } else {
      grid[choice] = '❌';
      addBudget(message.author.id, -bet);
      message.reply(`Peccato! Non hai trovato nulla. Hai perso €${bet.toLocaleString()}!\n${displayGrid()}`);
    }
  } catch (error) {
    message.reply('Tempo scaduto!');
  }
};

module.exports = { penguinGame };
