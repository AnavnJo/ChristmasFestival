const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const ORNAMENTS = [
  { name: 'Stella', emoji: '⭐', multiplier: 5 },
  { name: 'Palla', emoji: '🔴', multiplier: 2 },
  { name: 'Regalo', emoji: '🎁', multiplier: 3 },
  { name: 'Calza', emoji: '🧦', multiplier: 2.5 },
  { name: 'Campana', emoji: '🔔', multiplier: 4 },
  { name: 'Candela', emoji: '🕯️', multiplier: 2 },
  { name: 'Fiocco', emoji: '🎀', multiplier: 3.5 },
  { name: 'Angelo', emoji: '👼', multiplier: 4.5 }
];

class ChristmasTree {
  constructor() {
    this.grid = new Array(25).fill('🎄');
    this.placeOrnaments();
  }

  placeOrnaments() {
    ORNAMENTS.forEach(ornament => {
      let position;
      do {
        position = Math.floor(Math.random() * 25);
      } while (this.grid[position] !== '🎄');
      this.grid[position] = ornament;
    });
  }

  display() {
    let tree = '';
    for (let i = 0; i < this.grid.length; i++) {
      const item = this.grid[i];
      tree += typeof item === 'string' ? item : '🎄';
      tree += ' ';
      if ((i + 1) % 5 === 0) tree += '\n';
    }
    return tree;
  }

  revealOrnament(position) {
    return this.grid[position];
  }
}

const luckyTreeGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !albero <puntata>\nEsempio: !albero 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const tree = new ChristmasTree();
  
  let ornamentsList = '🎄 Decorazioni Disponibili 🎄\n';
  ORNAMENTS.forEach(o => {
    ornamentsList += `${o.emoji} ${o.name} (x${o.multiplier})\n`;
  });

  message.reply(`${ornamentsList}\nScegli una posizione sull'albero (1-25) per trovare una decorazione!\n${tree.display()}`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= 25;

  try {
    const collected = await message.channel.awaitMessages({ 
      filter, 
      max: 1, 
      time: 30000 
    });

    const choice = parseInt(collected.first().content) - 1;
    const result = tree.revealOrnament(choice);

    if (typeof result === 'string') {
      addBudget(message.author.id, -bet);
      message.reply(`😢 Hai trovato solo un ramo dell'albero! Hai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
    } else {
      const win = bet * result.multiplier;
      addBudget(message.author.id, win);
      message.reply(`🎉 Hai trovato un ${result.name} ${result.emoji}!\nHai vinto €${win.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
    }
  } catch (error) {
    message.reply('⏰ Tempo scaduto!');
  }
};

module.exports = { luckyTreeGame };
