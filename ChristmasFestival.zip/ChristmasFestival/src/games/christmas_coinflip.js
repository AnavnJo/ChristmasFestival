const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const christmasCoinflip = async (message, args) => {
  if (args.length !== 2) {
    return message.reply('Uso: !nataleflip <cometa/santa/elfo> <puntata>\nEsempio: !nataleflip cometa 1000');
  }

  const choice = args[0].toLowerCase();
  const bet = parseInt(args[1]);

  if (!['cometa', 'santa', 'elfo'].includes(choice)) {
    return message.reply('Devi scegliere tra cometa, santa o elfo!\nEsempio: !nataleflip cometa 1000');
  }

  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const options = ['cometa', 'santa', 'elfo'];
  const result = options[Math.floor(Math.random() * options.length)];
  const won = choice === result;

  const emojis = {
    cometa: '☄️',
    santa: '🎅',
    elfo: '🧝'
  };

  if (won) {
    const win = bet * 3; // Triple payout for 3-way choice
    addBudget(message.author.id, win);
    message.reply(`È uscito ${result} ${emojis[result]}! 🎉 Hai vinto €${win.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  } else {
    addBudget(message.author.id, -bet);
    message.reply(`È uscito ${result} ${emojis[result]}! 😢 Hai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  }
};

module.exports = { christmasCoinflip };
