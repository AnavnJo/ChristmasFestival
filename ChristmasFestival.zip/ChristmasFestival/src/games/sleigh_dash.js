const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const SLEIGHS = [
  { name: 'Rudolph', emoji: '🦌', multiplier: 2 },
  { name: 'Cometa', emoji: '☄️', multiplier: 3 },
  { name: 'Folgore', emoji: '⚡', multiplier: 4 },
  { name: 'Stella', emoji: '⭐', multiplier: 5 }
];

const sleighDashGame = async (message, args) => {
  if (args.length !== 2) {
    return message.reply('Uso: !slittadash <numero_slitta> <puntata>\nEsempio: !slittadash 1 1000');
  }

  const choice = parseInt(args[0]);
  const bet = parseInt(args[1]);

  if (isNaN(choice) || choice < 1 || choice > SLEIGHS.length) {
    return message.reply(`Scegli un numero di slitta valido (1-${SLEIGHS.length})`);
  }

  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  // Display sleighs
  let sleighList = '🎄 Gara delle Slitte di Natale 🎄\n\n';
  SLEIGHS.forEach((sleigh, index) => {
    sleighList += `${index + 1}. ${sleigh.name} ${sleigh.emoji} (x${sleigh.multiplier})\n`;
  });
  
  await message.reply(`${sleighList}\nLa gara sta per iniziare! Hai scelto la slitta ${SLEIGHS[choice - 1].name} ${SLEIGHS[choice - 1].emoji}`);

  // Race animation
  const positions = SLEIGHS.map((_, index) => ({ index, progress: 0 }));
  const raceLength = 5;
  
  for (let round = 1; round <= raceLength; round++) {
    let raceDisplay = '';
    positions.forEach(pos => {
      const sleigh = SLEIGHS[pos.index];
      const randomProgress = Math.floor(Math.random() * 3);
      pos.progress += randomProgress;
      
      const track = '—'.repeat(pos.progress) + sleigh.emoji + '—'.repeat(10 - pos.progress);
      raceDisplay += `${sleigh.name}: [${track}]\n`;
    });
    
    await message.channel.send(`Round ${round}:\n\`\`\`${raceDisplay}\`\`\``);
    
    // Add some delay between updates
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  // Determine winner
  positions.sort((a, b) => b.progress - a.progress);
  const winnerIndex = positions[0].index;
  const winner = SLEIGHS[winnerIndex];
  
  if (choice - 1 === winnerIndex) {
    const winAmount = bet * winner.multiplier;
    addBudget(message.author.id, winAmount);
    message.reply(`🎉 La tua slitta ha vinto! ${winner.name} ${winner.emoji} è arrivata prima!\nHai vinto €${winAmount.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  } else {
    addBudget(message.author.id, -bet);
    message.reply(`😢 Ha vinto ${winner.name} ${winner.emoji}!\nHai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  }
};

module.exports = { sleighDashGame };
