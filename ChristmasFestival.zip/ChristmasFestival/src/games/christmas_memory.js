const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const CARDS = [
  { name: 'Regalo', emoji: '🎁' },
  { name: 'Albero', emoji: '🎄' },
  { name: 'Babbo Natale', emoji: '🎅' },
  { name: 'Stella', emoji: '⭐' },
  { name: 'Campana', emoji: '🔔' },
  { name: 'Calza', emoji: '🧦' },
  { name: 'Fiocco di Neve', emoji: '❄️' },
  { name: 'Candela', emoji: '🕯️' }
];

class ChristmasMemory {
  constructor() {
    this.cards = [...CARDS, ...CARDS];
    this.shuffle();
    this.revealed = new Array(16).fill(false);
    this.firstChoice = null;
    this.matchedPairs = 0;
  }

  shuffle() {
    for (let i = this.cards.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.cards[i], this.cards[j]] = [this.cards[j], this.cards[i]];
    }
  }

  displayBoard() {
    let display = '';
    for (let i = 0; i < this.cards.length; i++) {
      if (this.revealed[i]) {
        display += this.cards[i].emoji + ' ';
      } else {
        display += `${i + 1}️⃣ `;
      }
      if ((i + 1) % 4 === 0) display += '\n';
    }
    return display;
  }

  makeMove(position) {
    if (position < 0 || position >= this.cards.length || this.revealed[position]) {
      return null;
    }

    this.revealed[position] = true;
    const currentCard = this.cards[position];

    if (this.firstChoice === null) {
      this.firstChoice = { position, card: currentCard };
      return { status: 'first', card: currentCard };
    } else {
      const match = this.firstChoice.card.name === currentCard.name;
      if (!match) {
        this.revealed[this.firstChoice.position] = false;
        this.revealed[position] = false;
      } else {
        this.matchedPairs++;
      }
      this.firstChoice = null;
      return { 
        status: match ? 'match' : 'no_match', 
        card: currentCard,
        firstCard: this.cards[this.firstChoice.position]
      };
    }
  }

  isGameComplete() {
    return this.matchedPairs === CARDS.length;
  }
}

const memoryGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !memory <puntata>\nEsempio: !memory 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const game = new ChristmasMemory();
  message.reply(`🎄 Memory di Natale 🎄\nTrova tutte le coppie! Scegli una carta (1-16)\n${game.displayBoard()}`);

  const filter = m => m.author.id === message.author.id && !isNaN(m.content) && 
                     parseInt(m.content) >= 1 && parseInt(m.content) <= 16;

  let moves = 0;
  const maxMoves = 20;

  while (moves < maxMoves && !game.isGameComplete()) {
    try {
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const choice = parseInt(collected.first().content) - 1;
      const result = game.makeMove(choice);

      if (!result) {
        message.reply('Carta non valida o già rivelata! Scegli un\'altra carta.');
        continue;
      }

      moves++;

      if (result.status === 'first') {
        message.reply(`Hai girato: ${result.card.emoji}\n${game.displayBoard()}\nScegli un'altra carta!`);
      } else if (result.status === 'match') {
        message.reply(`🎉 Coppia trovata! ${result.card.emoji}\n${game.displayBoard()}`);
      } else {
        message.reply(`❌ Non è una coppia! ${result.firstCard.emoji} ≠ ${result.card.emoji}\n${game.displayBoard()}`);
      }

    } catch (error) {
      return message.reply('⏰ Tempo scaduto!');
    }
  }

  if (game.isGameComplete()) {
    const win = bet * (1 + (maxMoves - moves) / 10);
    addBudget(message.author.id, win);
    message.reply(`🎉 Hai vinto! Hai completato il memory in ${moves} mosse!\nHai vinto €${win.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  } else {
    addBudget(message.author.id, -bet);
    message.reply(`😢 Game over! Non hai completato il memory in tempo.\nHai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
  }
};

module.exports = { memoryGame };
