const { MIN_BET, MAX_BET, GAMES } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const GIFTS = ['🎁', '🎄', '🎅', '⭐', '🔔'];

const giftGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !regalo <puntata>\nEsempio: !regalo 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const correctGift = GIFTS[Math.floor(Math.random() * GIFTS.length)];
  let attempts = GAMES.GIFT.MAX_ATTEMPTS;

  const filter = m => m.author.id === message.author.id;
  message.reply(`🎮 Indovina il regalo nascosto tra: ${GIFTS.join(' ')}!\n💫 Hai ${attempts} tentativi.\n💰 Puntata: €${bet.toLocaleString()}`);

  while (attempts > 0) {
    try {
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const guess = collected.first().content;
      if (!GIFTS.includes(guess)) {
        message.reply('❌ Scegli uno dei regali mostrati!');
        continue;
      }

      attempts--;

      if (guess === correctGift) {
        const win = bet * GAMES.GIFT.WIN_MULTIPLIER;
        addBudget(message.author.id, win);
        return message.reply(`🎉 Congratulazioni! Hai trovato il regalo giusto!\n💰 Hai vinto €${win.toLocaleString()}!\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
      } else {
        message.reply(`❌ Regalo sbagliato! Ti rimangono ${attempts} tentativi.`);
      }
    } catch (error) {
      return message.reply('⏰ Tempo scaduto!');
    }
  }

  addBudget(message.author.id, -bet);
  message.reply(`😢 Game over! Il regalo era ${correctGift}\n💸 Hai perso €${bet.toLocaleString()}\nNuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
};

module.exports = { giftGame };