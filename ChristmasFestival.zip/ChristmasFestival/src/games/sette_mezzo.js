const { MIN_BET, MAX_BET } = require('../config');
const { getBudget, addBudget } = require('../utils/budget');

const SEMI = {
  COPPE: { nome: 'Coppe', emoji: '🏆', simbolo: 'C' },
  BASTONI: { nome: 'Bastoni', emoji: '🏒', simbolo: 'B' },
  SPADE: { nome: 'Spade', emoji: '⚔️', simbolo: 'S' },
  DENARI: { nome: 'Denari', emoji: '💰', simbolo: 'D' }
};

const VALORI = {
  RE: { nome: 'Re', valore: 0.5, simbolo: 'R', display: 'Re' },
  CAVALLO: { nome: 'Cavallo', valore: 0.5, simbolo: 'C', display: 'Cavallo' },
  FANTE: { nome: 'Fante', valore: 0.5, simbolo: 'F', display: 'Fante' },
  SETTE: { nome: 'Sette', valore: 7, simbolo: '7', display: 'Sette' },
  SEI: { nome: 'Sei', valore: 6, simbolo: '6', display: 'Sei' },
  CINQUE: { nome: 'Cinque', valore: 5, simbolo: '5', display: 'Cinque' },
  QUATTRO: { nome: 'Quattro', valore: 4, simbolo: '4', display: 'Quattro' },
  TRE: { nome: 'Tre', valore: 3, simbolo: '3', display: 'Tre' },
  DUE: { nome: 'Due', valore: 2, simbolo: '2', display: 'Due' },
  ASSO: { nome: 'Asso', valore: 1, simbolo: 'A', display: 'Asso' }
};

// Barzellette da mostrare quando si perde
const BARZELLETTE = [
  "Qual è il colmo per un giocatore di carte? Perdere la pazienza! 😄",
  "Un giocatore al casinò chiede: 'Come si fa a uscire da qui?' Il croupier risponde: 'Facile, continui a giocare!' 😅",
  "Sai perché le carte da gioco non escono mai da sole? Perché vanno sempre in mazzo! 🃏",
  "Un mazzo di carte dice all'altro: 'Mi sembri un po' giù'. L'altro risponde: 'Sì, sono stato battuto!' 😂",
  "Cosa dice un Asso a un Due? 'Mi dispiace, ma io valgo di più!' 🎭",
  "Perché il Re di cuori è sempre triste? Perché la Regina gli ha rubato il cuore! ❤️",
  "Due carte parlano: 'Come stai?' 'Male, sono stata scartata...' 🎲",
  "Qual è il gioco preferito delle carte geografiche? Il poker mondiale! 🗺️",
  "Le carte da gioco hanno fatto una festa... è stato un successo, erano tutte sul pezzo! 🎉",
  "Sai perché il Jolly è sempre felice? Perché può essere chi vuole! 🃏"
];

class Carta {
  constructor(seme, valore) {
    this.seme = seme;
    this.valore = valore;
  }

  toString() {
    return `┌─────────┐
│${this.valore.simbolo} ${this.seme.simbolo}     │
│ ${this.seme.emoji}      │
│  ${this.valore.display.padEnd(6)}│
│     ${this.seme.simbolo} ${this.valore.simbolo}│
└─────────┘`;
  }

  getPunti() {
    return this.valore.valore;
  }
}

class Mazzo {
  constructor() {
    this.carte = [];
    for (const seme of Object.values(SEMI)) {
      for (const valore of Object.values(VALORI)) {
        this.carte.push(new Carta(seme, valore));
      }
    }
    this.mischia();
  }

  mischia() {
    for (let i = this.carte.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.carte[i], this.carte[j]] = [this.carte[j], this.carte[i]];
    }
  }

  pesca() {
    return this.carte.pop();
  }
}

class SetteEMezzo {
  constructor() {
    this.mazzo = new Mazzo();
    this.manoGiocatore = [this.mazzo.pesca()];
    this.manoBot = [this.mazzo.pesca()];
    this.giocatoreFermo = false;
    this.botFermo = false;
  }

  getPuntiMano(mano) {
    return mano.reduce((sum, carta) => sum + carta.getPunti(), 0);
  }

  pescaGiocatore() {
    if (!this.giocatoreFermo) {
      this.manoGiocatore.push(this.mazzo.pesca());
    }
  }

  giocaBot() {
    const puntiBot = this.getPuntiMano(this.manoBot);
    if (puntiBot < 6) {
      this.manoBot.push(this.mazzo.pesca());
      return true;
    }
    this.botFermo = true;
    return false;
  }

  getBarzelletta() {
    return BARZELLETTE[Math.floor(Math.random() * BARZELLETTE.length)];
  }
}

const setteEMezzoGame = async (message, args) => {
  if (args.length !== 1) {
    return message.reply('Uso: !setteemezzo <puntata>\nEsempio: !setteemezzo 1000');
  }

  const bet = parseInt(args[0]);
  if (isNaN(bet) || bet < MIN_BET || bet > MAX_BET) {
    return message.reply(`La puntata deve essere tra €${MIN_BET.toLocaleString()} e €${MAX_BET.toLocaleString()}`);
  }

  const userBudget = getBudget(message.author.id);
  if (bet > userBudget) {
    return message.reply(`Non hai abbastanza fondi per questa puntata! Il tuo budget attuale è €${userBudget.toLocaleString()}`);
  }

  const game = new SetteEMezzo();

  const displayMano = (mano) => mano.map(carta => carta.toString()).join('\n');

  message.reply(`
🎴 Sette e Mezzo 🎴

Le tue carte:
${displayMano(game.manoGiocatore)}

Punti: ${game.getPuntiMano(game.manoGiocatore)}

Vuoi un'altra carta? (si/no)`);

  const filter = m => m.author.id === message.author.id && 
                     ['si', 'no'].includes(m.content.toLowerCase());

  while (!game.giocatoreFermo) {
    try {
      const collected = await message.channel.awaitMessages({ 
        filter, 
        max: 1, 
        time: 30000 
      });

      const risposta = collected.first().content.toLowerCase();
      if (risposta === 'si') {
        game.pescaGiocatore();
        const punti = game.getPuntiMano(game.manoGiocatore);
        
        if (punti > 7.5) {
          addBudget(message.author.id, -bet);
          return message.reply(`
😢 Hai sballato con ${punti} punti!

Le tue carte:
${displayMano(game.manoGiocatore)}

${game.getBarzelletta()}

Hai perso €${bet.toLocaleString()}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
        }

        message.reply(`
Le tue carte:
${displayMano(game.manoGiocatore)}

Punti: ${punti}

Vuoi un'altra carta? (si/no)`);
      } else {
        game.giocatoreFermo = true;
      }
    } catch (error) {
      return message.reply('⏰ Tempo scaduto! Partita annullata.');
    }
  }

  // Turno del bot
  message.reply(`
🤖 Turno del bot:
${displayMano(game.manoBot)}`);

  while (!game.botFermo) {
    if (game.giocaBot()) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      message.reply(`
🤖 Il bot pesca:
${displayMano(game.manoBot)}`);
    }
  }

  const puntiGiocatore = game.getPuntiMano(game.manoGiocatore);
  const puntiBot = game.getPuntiMano(game.manoBot);

  let result = '';
  if (puntiBot > 7.5) {
    // Bot ha sballato
    const win = bet * 2;
    addBudget(message.author.id, win);
    result = `
🎉 Il bot ha sballato con ${puntiBot} punti!
Hai vinto €${win.toLocaleString()}!`;
  } else if (puntiGiocatore > puntiBot) {
    // Giocatore vince
    const win = bet * 2;
    addBudget(message.author.id, win);
    result = `
🎉 Hai vinto con ${puntiGiocatore} punti contro ${puntiBot}!
Hai vinto €${win.toLocaleString()}!`;
  } else if (puntiGiocatore === puntiBot) {
    // Pareggio
    result = `
🤝 Pareggio con ${puntiGiocatore} punti!
La puntata ti viene restituita.`;
  } else {
    // Bot vince
    addBudget(message.author.id, -bet);
    result = `
😢 Hai perso con ${puntiGiocatore} punti contro ${puntiBot}!

${game.getBarzelletta()}

Hai perso €${bet.toLocaleString()}`;
  }

  message.reply(`${result}
Nuovo budget: €${getBudget(message.author.id).toLocaleString()}`);
};

module.exports = { setteEMezzoGame };
