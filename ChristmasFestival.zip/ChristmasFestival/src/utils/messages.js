const { MIN_BET, MAX_BET } = require('../config');

const helpMessage = `
🎮 **Bot Giochi Natalizi** 🎄

Comandi disponibili:
• !help - Mostra questo messaggio
• !budget - Visualizza il tuo budget attuale
• !dona <importo> - Fai una donazione alla chiesa

Giochi disponibili:
1. **Coinflip** 
   • !coinflip <testa/croce> <puntata>
   • Indovina se uscirà testa o croce

2. **Christmas Coinflip** 🎅
   • !nataleflip <cometa/santa/elfo> <puntata>
   • Indovina chi apparirà tra Cometa, Santa o l'Elfo!

3. **Indovina il Regalo** 
   • !regalo <puntata>
   • Trova il regalo giusto tra quelli mostrati

4. **Trova il Pinguino**
   • !pinguino <puntata>
   • Trova il pinguino fortunato ma attento all'orso!

5. **Trova la Renna** 🦌
   • !renna <puntata>
   • Cerca la Renna Cometa nel mondo natalizio

6. **Salva gli Elfi** 🧝
   • !elfi <puntata>
   • Indovina quanti elfi stanno scappando con la slitta!

7. **Trova Santa Claus** 🎅
   • !trovasanta <puntata>
   • Cerca Santa nelle città del mondo!

8. **Pacchi del Polo Nord** 📦
   • !pacchi <puntata>
   • Apri i pacchi misteriosi e scopri cosa contengono!

9. **Gara delle Slitte** 🛷
   • !slittadash <numero_slitta> <puntata>
   • Scommetti sulla slitta vincitrice della gara!

10. **Memory di Natale** 🎭
    • !memory <puntata>
    • Trova le coppie di carte natalizie!

11. **Albero Fortunato** 🎄
    • !albero <puntata>
    • Scegli un ornamento dall'albero e vinci premi!

12. **Quiz di Conoscenza** 📚
    • !quiz <numero_categoria> <puntata>
    • Metti alla prova le tue conoscenze e vinci premi!
    • Categorie:
      1. Natale 🎄
      2. Astrofisica 🌌
      3. Astronomia 🔭
      4. Fisica ⚛️
      5. Matematica 📐
      6. Biologia Marina 🌊
      7. Biologia 🧬
      8. Storia 📚
      9. Storia dell'Arte 🎨

13. **Tombola Natalizia** 🎰
    • !tombola <puntata> - Inizia una nuova partita
    • !partecipa - Unisciti alla partita in corso
    • !via - Inizia l'estrazione dei numeri
    • !numero - Estrai il prossimo numero
    • !cartella - Visualizza la tua cartella
    • !ambo - Dichiara un ambo
    • !terna - Dichiara una terna
    • !cinquina - Dichiara una cinquina
    • !tombola - Dichiara tombola

14. **Briscola Siciliana** 🎴
    • !briscola <puntata>
    • Sfida il bot a briscola con le carte siciliane!
    • Vinci punti extra in base al punteggio finale

15. **Tris contro il Bot** 🎮
    • !tris <puntata>
    • Sfida il bot a tris!
    • Vinci il doppio della puntata
    • Pareggio = rimborso puntata

16. **Dadi** 🎲
    • !dadi <tipo> <puntata>
    • Cinque modalità di gioco:
      - somma: Indovina se la somma sarà sopra/sotto 7 (x2)
      - doppio: Punta sul doppio numero (x3)
      - poker: Quattro dadi uguali (x50)
      - scala: Quattro numeri consecutivi (x30)
      - tris: Tre dadi uguali (x15)

17. **Sette e Mezzo** 🎴
    • !setteemezzo <puntata>
    • Gioca a sette e mezzo con le carte siciliane!
    • Vinci il doppio della puntata
    • Bot racconta barzellette quando perdi! 😄

18. **Detective Renna Cometa** 🦌
    • !detective <tipo_caso> <puntata>
    • Aiuta Babbo Natale a risolvere crimini natalizi!
    • Tipi di casi:
      - Furto 🎁 (x2)
      - Rapina 💰 (x3)
      - Riscatto 📜 (x4)
      - Aggressione 👊 (x3)
      - Truffa 🎭 (x3)
      - Omicidio 🔪 (x5)
    • Usa !indizio per scoprire nuovi indizi
    • Usa !accusa <numero_sospetto> per accusare un sospetto
    • Bonus moltiplicatore per tentativi rimasti!

Limiti di puntata: €${MIN_BET} - €${MAX_BET}

Buona fortuna! 🎅
`;

module.exports = { helpMessage };