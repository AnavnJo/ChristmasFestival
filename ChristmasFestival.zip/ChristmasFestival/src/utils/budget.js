const { INITIAL_BUDGET } = require('../config');

// In-memory storage for user budgets
const budgets = new Map();

const getBudget = (userId) => {
  if (!budgets.has(userId)) {
    budgets.set(userId, INITIAL_BUDGET);
  }
  return budgets.get(userId);
};

const addBudget = (userId, amount) => {
  const currentBudget = getBudget(userId);
  budgets.set(userId, currentBudget + amount);
  return budgets.get(userId);
};

const donate = (userId, amount) => {
  const currentBudget = getBudget(userId);
  if (currentBudget < amount) {
    return false;
  }
  budgets.set(userId, currentBudget - amount);
  return true;
};

module.exports = { getBudget, addBudget, donate };
